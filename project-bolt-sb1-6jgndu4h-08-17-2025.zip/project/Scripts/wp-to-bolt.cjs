// scripts/wp-to-bolt.js
// Usage: node scripts/wp-to-bolt.js https://acreagesale.com
// Node 18+ required

const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");

// --- SETTINGS (protect your Bolt pages) ---
const BASE = process.argv[2];
if (!BASE) {
  console.error("Usage: node scripts/wp-to-bolt.js https://your-wp-site.com");
  process.exit(1);
}
const EXCLUDE_EXACT = new Set(["/"]);                 // keep Bolt homepage
const EXCLUDE_PREFIXES = ["/properties", "/property", "/dashboard"]; // keep Bolt routes
const PATH_REMAP = { "/": "/home-old" };              // WP home → /home-old (adjust if you want)

// --- Project paths ---
const ROOT = process.cwd();
const SRC_DIR = path.join(ROOT, "src");
const PAGES_DIR = path.join(SRC_DIR, "pages", "wp");     // generated TSX files go here
const ROUTES_FILE = path.join(SRC_DIR, "wp", "routes.tsx");
const ROUTES_DIR = path.dirname(ROUTES_FILE);
const MEDIA_DIR = path.join(ROOT, "public", "wp-media");

async function ensureDirs() {
  await fsp.mkdir(PAGES_DIR, { recursive: true });
  await fsp.mkdir(ROUTES_DIR, { recursive: true });
  await fsp.mkdir(MEDIA_DIR, { recursive: true });
}

function shouldSkip(pathname) {
  if (EXCLUDE_EXACT.has(pathname)) return true;
  for (const p of EXCLUDE_PREFIXES) {
    if (p !== "/" && pathname.startsWith(p + "/")) return true;
  }
  return false;
}
const applyPathRemap = (p) => PATH_REMAP[p] || p;
const slugifyFilename = (s) =>
  s.toLowerCase().replace(/[^a-z0-9._-]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");

function extractImageSrcs(html) {
  const set = new Set();
  const re = /<img[^>]+src=["']([^"']+)["']/gi;
  let m;
  while ((m = re.exec(html))) set.add(m[1]);
  return Array.from(set);
}

async function mirrorImage(url) {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const buf = Buffer.from(await res.arrayBuffer());
    const u = new URL(url);
    const raw = u.pathname.split("/").filter(Boolean).slice(-3).join("_") || "img";
    const fname = slugifyFilename(raw);
    const outPath = path.join(MEDIA_DIR, fname);
    await fsp.writeFile(outPath, buf);
    return `/wp-media/${fname}`;
  } catch {
    return null;
  }
}

function rewriteInternalLinks(html, BASE) {
  return html.replace(/<a\s+[^>]*href=["']([^"']+)["'][^>]*>/gi, (m, href) => {
    try {
      const u = new URL(href, BASE);
      if (u.host !== new URL(BASE).host) return m; // external
      let p = u.pathname || "/";
      if (p.length > 1 && p.endsWith("/")) p = p.slice(0, -1);
      const newPath = applyPathRemap(p);
      if (!shouldSkip(newPath)) return m.replace(href, newPath || "/");
    } catch {}
    return m;
  });
}

const escapeForTsx = (html) => html.replace(/`/g, "\\`").replace(/\$\{/g, "\\${");

async function fetchAll(endpoint) {
  let page = 1;
  const perPage = 100;
  const all = [];
  while (true) {
    const url = `${BASE}/wp-json/wp/v2/${endpoint}?status=publish&per_page=${perPage}&page=${page}&_embed`;
    const res = await fetch(url);
    if (!res.ok) {
      if (res.status === 400 || res.status === 404) break;
      throw new Error(`Fetch failed ${res.status} for ${url}`);
    }
    const items = await res.json();
    all.push(...items);
    const totalPages = parseInt(res.headers.get("X-WP-TotalPages") || "1", 10);
    if (page >= totalPages) break;
    page++;
  }
  return all;
}

function pathToFs(pathname) {
  const segs = pathname.split("/").filter(Boolean);
  const dir = path.join(PAGES_DIR, ...segs);
  const file = path.join(dir, "index.tsx");
  return { dir, file };
}

// Build /parent/child URL from WP hierarchy
function buildPathFromHierarchy(page, byId) {
  const parts = [];
  let cur = page;
  while (cur && cur.id) {
    const s = (cur.slug || "").trim();
    if (s) parts.push(s);
    cur = cur.parent ? byId.get(cur.parent) : null;
  }
  parts.reverse();
  let pathname = "/" + parts.join("/");
  if (pathname.length > 1 && pathname.endsWith("/")) pathname = pathname.slice(0, -1);
  return pathname || "/";
}

async function writeTsxPage({ pathname, title, content, featured_image }) {
  const { dir, file } = pathToFs(pathname);
  await fsp.mkdir(dir, { recursive: true });

  // ⛔ never overwrite if already present
  try { await fsp.access(file); console.log(`⏭️  Exists, skipping: ${pathname}`); return file; } catch {}

  const tsx = `import React from "react";

export default function WP_${pathname === "/" ? "Home" : pathname.split("/").filter(Boolean).join("_") || "Page"}() {
  return (
    <main className="max-w-5xl mx-auto p-6">
      ${title ? `<h1 className="text-3xl font-semibold mb-4" dangerouslySetInnerHTML={{ __html: \`${escapeForTsx(title)}\` }} />` : ""}
      ${featured_image ? `<img src="${featured_image}" alt="" className="mb-6 w-full rounded-xl" />` : ""}
      <article className="prose lg:prose-lg max-w-none" dangerouslySetInnerHTML={{ __html: \`${escapeForTsx(content)}\` }} />
    </main>
  );
}
`;
  await fsp.writeFile(file, tsx, "utf8");
  return file;
}

async function run() {
  await ensureDirs();
  console.log("🔎 Fetching WP pages…");
  const pages = await fetchAll("pages");
  const byId = new Map(pages.map((p) => [p.id, p]));
  console.log(`✅ Found ${pages.length} pages`);

  const routes = [];

  for (const p of pages) {
    let pathname = buildPathFromHierarchy(p, byId);
    pathname = applyPathRemap(pathname);
    if (shouldSkip(pathname)) { console.log(`⏭️  Skipping protected: ${pathname}`); continue; }

    let html = p.content?.rendered || "";
    html = rewriteInternalLinks(html, BASE);

    // Mirror inline images
    const imgs = extractImageSrcs(html);
    for (const src of imgs) {
      const mirrored = await mirrorImage(src);
      if (mirrored) html = html.replaceAll(src, mirrored);
    }

    // Featured image
    let featured_image = null;
    const media = p._embedded?.["wp:featuredmedia"]?.[0];
    if (media?.source_url) {
      const mirrored = await mirrorImage(media.source_url);
      if (mirrored) featured_image = mirrored;
    }

    const tsxPath = await writeTsxPage({ pathname, title: p.title?.rendered || "", content: html, featured_image });
    routes.push({ path: pathname, importPath: tsxPath });
    console.log(`📝 ${pathname} → ${path.relative(ROOT, tsxPath)}`);
  }

  // Build routes file with lazy imports
  const routeLines = routes.map((r) => {
    const relFromRoutes = path.relative(ROUTES_DIR, r.importPath).replaceAll(path.sep, "/");
    return `  { path: "${r.path}", loader: () => import("${relFromRoutes}").then(m => ({ default: m.default })) }`;
  });

  const routesTsx = `import React, { lazy } from "react";
export const wpGeneratedRoutes = [
${routeLines.join(",\n")}
];
export function buildWpRoutes() {
  return wpGeneratedRoutes.map(r => {
    const Comp = lazy(r.loader);
    return { path: r.path, element: <Comp /> };
  });
}
`;
  await fsp.writeFile(ROUTES_FILE, routesTsx, "utf8");
  console.log(`📦 Wrote routes → ${path.relative(ROOT, ROUTES_FILE)}`);
  console.log("🎉 Done.");
}

run().catch((e) => { console.error(e); process.exit(1); });
