import { createClient } from '@supabase/supabase-js';
import fs from 'fs';

// 🔑 Replace with your Supabase credentials
const supabaseUrl = 'https://cafpmnrrhhelopmzwspj.supabase.co';
const serviceKey = 'YOUR_SERVICE_ROLE_KEY'; // Use Service Role Key, not anon
const supabase = createClient(supabaseUrl, serviceKey);

const BUCKET_NAME = 'property-images';

async function migrateImages() {
  try {
    console.log('🚀 Starting image migration...');
    
    // Ensure bucket exists
    const { data: buckets, error: bucketError } = await supabase.storage.listBuckets();
    if (bucketError) throw bucketError;

    const exists = buckets.some((b) => b.name === BUCKET_NAME);
    if (!exists) {
      const { error } = await supabase.storage.createBucket(BUCKET_NAME, { public: true });
      if (error) throw error;
      console.log(`✅ Created bucket: ${BUCKET_NAME}`);
    } else {
      console.log(`✅ Bucket ${BUCKET_NAME} already exists`);
    }

    // Fetch properties with images
    console.log('📋 Fetching properties...');
    const { data: properties, error: fetchError } = await supabase
      .from('properties')
      .select('id, images')
      .not('images', 'is', null);

    if (fetchError) throw fetchError;
    console.log(`📊 Found ${properties.length} properties to process`);

    let processedCount = 0;
    let skippedCount = 0;
    let errorCount = 0;

    for (const property of properties) {
      if (!property.images || property.images.length === 0) {
        skippedCount++;
        continue;
      }

      console.log(`🔄 Processing property ${property.id}...`);
      let newImageUrls = [];
      let hasBase64Images = false;

      for (let i = 0; i < property.images.length; i++) {
        const imgData = property.images[i];

        // If already a URL, keep it
        if (typeof imgData === 'string' && (imgData.startsWith('http') || imgData.startsWith('https'))) {
          newImageUrls.push(imgData);
          continue;
        }

        // Check if it's base64 data
        if (typeof imgData === 'string' && imgData.startsWith('data:image/')) {
          hasBase64Images = true;
          
          try {
            // Extract base64 data
            const base64Data = imgData.replace(/^data:image\/\w+;base64,/, '');
            const buffer = Buffer.from(base64Data, 'base64');
            
            // Determine file extension from data URL
            const mimeMatch = imgData.match(/data:image\/(\w+);base64,/);
            const extension = mimeMatch ? mimeMatch[1] : 'jpg';
            const fileName = `property-${property.id}-${i}.${extension}`;

            // Upload to Supabase Storage
            const { error: uploadError } = await supabase.storage
              .from(BUCKET_NAME)
              .upload(fileName, buffer, {
                contentType: `image/${extension}`,
                upsert: true,
              });

            if (uploadError) {
              console.error(`❌ Failed to upload image ${i} for property ${property.id}:`, uploadError.message);
              errorCount++;
              // Keep original base64 data if upload fails
              newImageUrls.push(imgData);
              continue;
            }

            // Get public URL
            const { data: urlData } = supabase.storage.from(BUCKET_NAME).getPublicUrl(fileName);
            newImageUrls.push(urlData.publicUrl);
            console.log(`✅ Uploaded image ${i} for property ${property.id}`);
            
          } catch (error) {
            console.error(`❌ Error processing image ${i} for property ${property.id}:`, error.message);
            errorCount++;
            // Keep original data if processing fails
            newImageUrls.push(imgData);
          }
        } else {
          // Unknown format, keep as is
          newImageUrls.push(imgData);
        }
      }

      // Update property only if we found base64 images to migrate
      if (hasBase64Images) {
        const { error: updateError } = await supabase
          .from('properties')
          .update({ images: newImageUrls })
          .eq('id', property.id);

        if (updateError) {
          console.error(`❌ Failed to update property ${property.id}:`, updateError.message);
          errorCount++;
        } else {
          console.log(`✅ Updated property ${property.id} with ${newImageUrls.length} images`);
          processedCount++;
        }
      } else {
        console.log(`⏭️ Skipped property ${property.id} (no base64 images found)`);
        skippedCount++;
      }
    }

    console.log('\n🎉 Migration complete!');
    console.log(`📊 Summary:`);
    console.log(`   - Processed: ${processedCount} properties`);
    console.log(`   - Skipped: ${skippedCount} properties`);
    console.log(`   - Errors: ${errorCount} errors`);
    
  } catch (error) {
    console.error('💥 Migration failed:', error.message);
    process.exit(1);
  }
}

// Run the migration
migrateImages().catch((err) => {
  console.error('💥 Migration error:', err);
  process.exit(1);
});