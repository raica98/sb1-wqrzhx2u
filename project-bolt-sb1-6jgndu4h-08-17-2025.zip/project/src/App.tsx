import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { lazy, Suspense } from 'react';
import 'mapbox-gl/dist/mapbox-gl.css';
import { Homepage } from './screens/Homepage/Homepage';
import { Properties } from './pages/Properties';
import { PropertyDetail } from './pages/PropertyDetail';
import { Dashboard } from './pages/Dashboard';
import { EditProperty } from './pages/EditProperty';
import { DashboardEditListing } from './pages/DashboardEditListing';
import { DashboardInbox } from './pages/DashboardInbox';
import { Inbox } from './pages/Inbox';
import WP_exploring_vacant_land_opportunities_in_phelan_a_5_acre_lot_with_utility_access from './wp/exploring-vacant-land-opportunities-in-phelan-a-5-acre-lot-with-utility-access';
import { useAuth } from './hooks/useAuth';

// Lazy load WP pages
const WpDallas = lazy(() => import('./pages/wp/land-for-sale-in-dallas'));

// Protected Route Component
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <div className="text-xl font-semibold text-gray-700">Loading...</div>
        </div>
      </div>
    );
  }
  
  if (!user) {
    return <Homepage />;
  }
  
  return <>{children}</>;
}

export function App() {
  console.log('🔍 DEBUG: App component rendered');
  console.log('🔍 DEBUG: Current URL:', window.location.href);
  
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/properties" element={<Properties />} />
        <Route path="/property/:id" element={<PropertyDetail />} />
        <Route path="/dashboard" element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        } />
        <Route path="/dashboard/edit/:id" element={
          <ProtectedRoute>
            <DashboardEditListing />
          </ProtectedRoute>
        } />
        <Route path="/dashboard/inbox" element={
          <ProtectedRoute>
            <DashboardInbox />
          </ProtectedRoute>
        } />
        <Route path="/edit-property/:id" element={
          <ProtectedRoute>
            <EditProperty />
          </ProtectedRoute>
        } />

        <Route
  path="/exploring-vacant-land-opportunities-in-phelan-a-5-acre-lot-with-utility-access"
  element={<WP_exploring_vacant_land_opportunities_in_phelan_a_5_acre_lot_with_utility_access />}
/>

        <Route
          path="/land-for-sale-in-dallas"
          element={
            <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><div className="text-xl font-semibold text-gray-700">Loading…</div></div>}>
              <WpDallas />
            </Suspense>
          }
        />

        <Route path="*" element={<div>Page not found</div>} />
      </Routes>
    </Router>
  );
}