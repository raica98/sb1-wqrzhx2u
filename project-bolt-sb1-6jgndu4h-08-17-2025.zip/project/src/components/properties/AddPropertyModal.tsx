import React, { useState } from 'react';
import { X, Plus } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { PropertyListingForm } from './PropertyListingForm';
import { IntegratedListingFlow } from './IntegratedListingFlow';
import { AIAutoListingGenerator } from './AIAutoListingGenerator';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../hooks/useAuth';

interface AddPropertyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function AddPropertyModal({ isOpen, onClose, onSuccess }: AddPropertyModalProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedFlow, setSelectedFlow] = useState<'manual' | 'integrated' | 'ai' | null>(null);

  // Simple geocoding function
  const geocodeAddress = async (address: string, city: string, state: string): Promise<{ lat: number; lng: number } | null> => {
    try {
      const fullAddress = `${address}, ${city}, ${state}`;
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(fullAddress)}&limit=1&countrycodes=us`,
        {
          headers: {
            'User-Agent': 'AcreageSale/1.0'
          }
        }
      );
      
      const data = await response.json();
      
      if (data && data.length > 0) {
        return {
          lat: parseFloat(data[0].lat),
          lng: parseFloat(data[0].lon),
        };
      }
    } catch (error) {
      console.error('Geocoding error:', error);
    }
    return null;
  };

  const handleSubmit = async (data: any) => {
    if (!user) {
      setError('You must be logged in to create a property listing');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Geocode the address
      const coordinates = await geocodeAddress(data.address, data.city, data.state);

      const propertyData = {
        user_id: user.id,
        title: data.title,
        description: data.description,
        price: data.price,
        size_acres: data.size_acres,
        address: data.address,
        city: data.city,
        state: data.state,
        zip_code: data.zip_code,
        county: data.county || null,
        apn: data.apn || null,
        latitude: coordinates?.lat || null,
        longitude: coordinates?.lng || null,
        zoning: data.zoning || null,
        water: data.water || null,
        electricity: data.electricity || null,
        sewer: data.sewer || null,
        zoning: data.zoning || null,
        water: data.water || null,
        electricity: data.electricity || null,
        sewer: data.sewer || null,
        latitude: data.latitude || null,
        longitude: data.longitude || null,
        images: data.images || [],
        boundary_points: data.boundary_points || null,
        status: 'active',
      };

      const { error } = await supabase.from('properties').insert([propertyData]);

      if (error) throw error;

      onSuccess();
      onClose();
      setSelectedFlow(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    onClose();
    setSelectedFlow(null);
    setError(null);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-start justify-center z-50 p-4 overflow-y-auto">
      <div className="w-full max-w-7xl mx-auto my-4 lg:my-8 pt-4 lg:pt-8">
        {!selectedFlow ? (
          // Flow Selection Screen
          <Card className="bg-white shadow-2xl border-0 rounded-2xl overflow-hidden max-w-4xl mx-auto">
            <CardContent className="p-0 bg-white opacity-100">
              <div className="p-4 lg:p-8 relative">
              {/* Exit button in top right corner */}
              <button
                onClick={handleClose}
                className="absolute top-4 right-4 w-8 h-8 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center transition-colors z-10 shadow-md"
                aria-label="Close modal"
              >
                <X className="w-4 h-4 text-gray-600" />
              </button>
              
              {/* Hero Section */}
              <div className="text-center mb-6 lg:mb-12">
                <div className="w-12 h-12 lg:w-20 lg:h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-3 lg:mb-6">
                  <span className="text-white text-3xl">🚀</span>
                </div>
                <h2 className="text-xl lg:text-3xl font-bold text-gray-900 mb-2 lg:mb-4 px-2">
                  Choose Your Listing Method
                </h2>
                </div>

              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-3 lg:px-6 py-2 lg:py-4 rounded-xl mb-4 lg:mb-8 mx-2 lg:mx-0">
                  {error}
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 lg:gap-8 max-w-5xl mx-auto px-1 lg:px-0">
                {/* Smart Map Flow */}

                {/* Integrated Flow */}
                <div 
                  onClick={() => setSelectedFlow('integrated')}
                  className="group cursor-pointer bg-white opacity-100 rounded-lg lg:rounded-3xl p-3 lg:p-8 border-2 border-blue-200 hover:border-blue-400 hover:shadow-2xl transition-all duration-300 transform hover:scale-[1.02] relative"
                >
                  {/* Recommended Badge */}
                  <div className="absolute top-1 lg:top-4 right-1 lg:right-4 bg-green-600 text-white px-2 lg:px-3 py-1 rounded-full text-xs font-bold">
                    RECOMMENDED
                  </div>
                  
                  <div className="relative z-10">
                    {/* Icon */}
                    <div className="w-10 h-10 lg:w-20 lg:h-20 bg-blue-600 rounded-lg lg:rounded-3xl flex items-center justify-center mx-auto mb-2 lg:mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                      <span className="text-white text-xl lg:text-3xl">🗺️</span>
                    </div>
                    
                    {/* Title */}
                    <h3 className="text-base lg:text-2xl font-bold text-gray-900 mb-1 lg:mb-4 text-center">
                      Smart Map Flow
                    </h3>
                    
                    {/* Description */}
                    <p className="text-gray-600 mb-3 lg:mb-8 text-xs lg:text-base leading-tight lg:leading-relaxed text-center">
                      The intelligent way to create listings. Our AI analyzes your property data and generates professional content automatically.
                    </p>
                    
                    {/* Features */}
                    <div className="space-y-1 lg:space-y-4 mb-3 lg:mb-8">
                      <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                        <div className="w-3 h-3 lg:w-6 lg:h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-blue-600 text-xs">🗺️</span>
                        </div>
                        <span className="font-medium text-xs lg:text-base">Interactive satellite mapping</span>
                      </div>
                      <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                        <div className="w-3 h-3 lg:w-6 lg:h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-green-600 text-xs">🤖</span>
                        </div>
                        <span className="font-medium text-xs lg:text-base">AI-powered content generation</span>
                      </div>
                      <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                        <div className="w-3 h-3 lg:w-6 lg:h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-purple-600 text-xs">⚡</span>
                        </div>
                        <span className="font-medium text-xs lg:text-base">Automatic property data lookup</span>
                      </div>
                      <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                        <div className="w-3 h-3 lg:w-6 lg:h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-orange-600 text-xs">📸</span>
                        </div>
                        <span className="font-medium text-xs lg:text-base">AI satellite image capture</span>
                      </div>
                      <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                        <div className="w-3 h-3 lg:w-6 lg:h-6 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-red-600 text-xs">🎯</span>
                        </div>
                        <span className="font-medium text-xs lg:text-base">Market to buyers in the area</span>
                      </div>
                      <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                        <div className="w-3 h-3 lg:w-6 lg:h-6 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-yellow-600 text-xs">💰</span>
                        </div>
                        <span className="font-medium text-xs lg:text-base">Matching to in the area buyers</span>
                      </div>
                      <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                        <div className="w-3 h-3 lg:w-6 lg:h-6 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-indigo-600 text-xs">🎯</span>
                        </div>
                        <span className="font-medium text-xs lg:text-base">Direct buyer offers - zero commissions, maximum control </span>
                      </div>
                      <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                        <div className="w-3 h-3 lg:w-6 lg:h-6 bg-teal-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-teal-600 text-xs">📊</span>
                        </div>
                        <span className="font-medium text-xs lg:text-base">Real-time market analytics and pricing insights</span>
                      </div>
                      <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                        <div className="w-3 h-3 lg:w-6 lg:h-6 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-emerald-600 text-xs">⚡</span>
                        </div>
                        <span className="font-medium text-xs lg:text-base">Get offers as soon as 7 days!</span>
                      </div>
                      <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                        <div className="w-3 h-3 lg:w-6 lg:h-6 bg-pink-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-pink-600 text-xs">🎯</span>
                        </div>
                        <span className="font-medium text-xs lg:text-base">Targeted marketing to qualified investors</span>
                      </div>
                    </div>
                    
                    {/* Time Estimate */}
                    <div className="bg-blue-50 rounded-lg lg:rounded-2xl p-2 lg:p-4 mb-3 lg:mb-6 text-center">
                      <div className="text-sm lg:text-2xl font-bold text-blue-600">$200/month</div>
                      <div className="text-xs lg:text-sm text-blue-700">AI-powered automation</div>
                    </div>
                    
                    {/* Button */}
                    <Button className="w-full h-8 lg:h-12 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs lg:text-lg rounded-md lg:rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
                      Start Smart Flow
                    </Button>
                  </div>
                </div>

                {/* Manual Entry */}
                {/* Manual Form */}
                <div 
                  onClick={() => setSelectedFlow('manual')}
                  className="group cursor-pointer bg-white opacity-100 rounded-lg lg:rounded-3xl p-3 lg:p-8 border-2 border-gray-200 hover:border-gray-400 hover:shadow-2xl transition-all duration-300 transform hover:scale-[1.02] relative"
                >
                  <div className="relative z-10">
                    {/* Icon */}
                    <div className="w-10 h-10 lg:w-20 lg:h-20 bg-gray-600 rounded-lg lg:rounded-3xl flex items-center justify-center mx-auto mb-2 lg:mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                      <span className="text-white text-xl lg:text-3xl">📝</span>
                    </div>
                    
                    {/* Title */}
                    <h3 className="text-base lg:text-2xl font-bold text-gray-900 mb-1 lg:mb-4 text-center">
                      Manual Entry
                    </h3>
                    
                    {/* Description */}
                    <p className="text-gray-600 mb-3 lg:mb-8 text-xs lg:text-base leading-tight lg:leading-relaxed text-center">
                      Complete control over your listing. Perfect for experienced users who want to customize every detail.
                    </p>
                    
                    {/* Features */}
                    <div className="space-y-1 lg:space-y-4 mb-3 lg:mb-8">
                      <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                        <div className="w-3 h-3 lg:w-6 lg:h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-green-600 text-xs">✏️</span>
                        </div>
                        <span className="font-medium text-xs lg:text-base">Complete creative control</span>
                      </div>
                      <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                        <div className="w-3 h-3 lg:w-6 lg:h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-blue-600 text-xs">📷</span>
                        </div>
                        <span className="font-medium text-xs lg:text-base">Upload custom images</span>
                      </div>
                      <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                        <div className="w-3 h-3 lg:w-6 lg:h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-purple-600 text-xs">📋</span>
                        </div>
                        <span className="font-medium text-xs lg:text-base">Detailed form fields</span>
                      </div>
                      <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                        <div className="w-3 h-3 lg:w-6 lg:h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-orange-600 text-xs">🎯</span>
                        </div>
                        <span className="font-medium text-xs lg:text-base">Custom descriptions & pricing</span>
                      </div>
                    </div>
                    
                    {/* Time Estimate */}
                    <div className="bg-gray-50 rounded-lg lg:rounded-2xl p-2 lg:p-4 mb-3 lg:mb-6 text-center">
                      <div className="text-sm lg:text-2xl font-bold text-green-600">FREE</div>
                      <div className="text-xs lg:text-sm text-gray-700">No subscription required</div>
                    </div>
                    
                    {/* Button */}
                    <Button className="w-full h-8 lg:h-12 bg-gray-600 hover:bg-gray-700 text-white font-bold text-xs lg:text-lg rounded-md lg:rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
                      Start Manual Entry
                    </Button>
                  </div>
                </div>
              </div>

              {/* Bottom Section */}
              <div className="pt-3 lg:pt-8 text-center border-t border-gray-200 mx-1 lg:mx-0">
                <div className="max-w-3xl mx-auto px-0 lg:px-0">
                  <div className="flex items-center justify-center gap-1 mb-2 lg:mb-4">
                    <span className="text-lg lg:text-2xl">💡</span>
                    <h3 className="text-xs lg:text-lg font-bold text-gray-900">Need Help Choosing?</h3>
                  </div>
                  <p className="text-gray-600 mb-2 lg:mb-6 text-xs lg:text-base leading-tight lg:leading-normal px-2 lg:px-0">
                    <strong>New to land sales?</strong> Choose Smart Map Flow for AI assistance and guided setup.<br/>
                    <strong>Experienced seller?</strong> Manual Entry gives you complete control over every detail.
                  </p>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-1 lg:gap-6 max-w-2xl mx-auto bg-white opacity-100 px-2 lg:px-0">
                    <div className="bg-white rounded-md lg:rounded-xl p-1 lg:p-4 border border-blue-200">
                      <div className="text-blue-600 font-bold mb-1 text-xs lg:text-base">Smart Map Flow</div>
                      <div className="text-xs lg:text-sm text-gray-600">Best for first-time sellers</div>
                    </div>
                    <div className="bg-white rounded-md lg:rounded-xl p-1 lg:p-4 border border-gray-200">
                      <div className="text-gray-700 font-bold mb-1 text-xs lg:text-base">Manual Entry</div>
                      <div className="text-xs lg:text-sm text-gray-600">Best for experienced sellers</div>
                    </div>
                  </div>
                  
                  {/* New field added below the selected input */}
                  <div 
                    onClick={() => setSelectedFlow('integrated')}
                    className="group cursor-pointer bg-white opacity-100 rounded-lg lg:rounded-3xl p-3 lg:p-8 border-2 border-gray-200 hover:border-gray-400 hover:shadow-2xl transition-all duration-300 transform hover:scale-[1.02] relative"
                  >
                    <div className="relative z-10">
                      {/* Icon */}
                      <div className="w-10 h-10 lg:w-20 lg:h-20 bg-purple-600 rounded-lg lg:rounded-3xl flex items-center justify-center mx-auto mb-2 lg:mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                        <span className="text-white text-xl lg:text-3xl">🎯</span>
                      </div>
                      
                      {/* Title */}
                      <h3 className="text-base lg:text-2xl font-bold text-gray-900 mb-1 lg:mb-4 text-center">
                        Advanced Analytics
                      </h3>
                      
                      {/* Description */}
                      <p className="text-gray-600 mb-3 lg:mb-8 text-xs lg:text-base leading-tight lg:leading-relaxed text-center">
                        Get detailed market insights and investment analytics for your property listing decisions.
                      </p>
                      
                      {/* Features */}
                      <div className="space-y-1 lg:space-y-4 mb-3 lg:mb-8">
                        <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                          <div className="w-3 h-3 lg:w-6 lg:h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                            <span className="text-purple-600 text-xs">📊</span>
                          </div>
                          <span className="font-medium text-xs lg:text-base">Market trend analysis</span>
                        </div>
                        <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                          <div className="w-3 h-3 lg:w-6 lg:h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                            <span className="text-purple-600 text-xs">💰</span>
                          </div>
                          <span className="font-medium text-xs lg:text-base">ROI projections</span>
                        </div>
                        <div className="flex items-center gap-2 lg:gap-3 text-gray-700">
                          <div className="w-3 h-3 lg:w-6 lg:h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                            <span className="text-purple-600 text-xs">🎯</span>
                          </div>
                          <span className="font-medium text-xs lg:text-base">Buyer targeting insights</span>
                        </div>
                      </div>
                      
                      {/* Time Estimate */}
                      <div className="bg-purple-50 rounded-lg lg:rounded-2xl p-2 lg:p-4 mb-3 lg:mb-6 text-center">
                        <div className="text-sm lg:text-2xl font-bold text-purple-600">$99/month</div>
                        <div className="text-xs lg:text-sm text-purple-700">Advanced analytics</div>
                      </div>
                      
                      {/* Button */}
                      <Button className="w-full h-8 lg:h-12 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs lg:text-lg rounded-md lg:rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
                        Start Analytics Flow
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          // Selected Flow Component
          <div>
            {selectedFlow === 'integrated' && (
              <IntegratedListingFlow
                onSubmit={handleSubmit}
                onClose={handleClose}
                loading={loading}
              />
            )}
            {selectedFlow === 'manual' && (
              <PropertyListingForm
                onSubmit={handleSubmit}
                onClose={handleClose}
                loading={loading}
              />
            )}
          </div>
        )}
      </div>
    </div>
  );
}