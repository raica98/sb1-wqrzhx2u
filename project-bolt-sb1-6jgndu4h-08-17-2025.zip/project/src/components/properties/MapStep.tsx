import React, { useRef, useEffect, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import wellknown from 'wellknown'; // ✅ convert WKT to GeoJSON
import * as turf from '@turf/turf';
import { Button } from '../ui/button';
import { MapPin, Navigation, RotateCcw } from 'lucide-react';

const MAPBOX_TOKEN = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN || '';
if (MAPBOX_TOKEN) {
  mapboxgl.accessToken = MAPBOX_TOKEN;
}

// Utility: fit any GeoJSON geometry tightly without cutting off
function fitGeometryTight(
  map: mapboxgl.Map,
  geometry: GeoJSON.Geometry | GeoJSON.Polygon | GeoJSON.MultiPolygon,
  opts?: { minPadPx?: number; marginPct?: number; maxZoom?: number }
) {
  const { minPadPx = 8, marginPct = 0.02, maxZoom = 22 } = opts || {};

  // 1) Get bbox in [minX, minY, maxX, maxY]
  const bbox = turf.bbox(geometry as any);

  // 2) Convert to LngLatBounds
  const bounds = new mapboxgl.LngLatBounds(
    [bbox[0], bbox[1]],
    [bbox[2], bbox[3]]
  );

  // 3) Compute pixel padding dynamically from container size
  const el = map.getContainer();
  const w = el.clientWidth || 800;
  const h = el.clientHeight || 600;
  // padding is 2% of the smaller side, with a floor so outlines/markers don't clip
  let padPx = Math.max(Math.round(Math.min(w, h) * marginPct), minPadPx);

  // Optional: add a few pixels for thick outlines/markers you draw
  // padPx += 8;

  // 4) Ask mapbox for the tightest camera that fits those bounds
  const cam = map.cameraForBounds(bounds, {
    padding: padPx,
    maxZoom,                             // allow close zoom if parcel is tiny
    bearing: map.getBearing(),           // keep current view so fit respects it
    pitch: map.getPitch()
  });

  if (cam) {
    map.easeTo({ ...cam, duration: 1200 });
  }
}

interface MapStepProps {
  coordinates: { lat: number | null; lng: number | null };
  setCoordinates: (coords: { lat: number; lng: number }) => void;
  polygonGeometry?: any;
  onNext: () => void;
  onBack: () => void;
  address?: string;
  parcelWKT?: string; // ✅ pass polygon from ReportAll
}

const MapStep: React.FC<MapStepProps> = ({
  coordinates,
  setCoordinates,
  polygonGeometry,
  onNext,
  onBack,
  address,
  parcelWKT
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<mapboxgl.Map | null>(null);
  const markerRef = useRef<mapboxgl.Marker | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isMapLoaded, setIsMapLoaded] = useState(false);

  useEffect(() => {
    if (!mapContainerRef.current || !mapboxgl.accessToken) {
      console.error('Mapbox access token not found');
      setIsLoading(false);
      return;
    }

    setIsMapLoaded(false);
    const mapbox = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: 'mapbox://styles/mapbox/satellite-streets-v12',
      center: [coordinates?.lng || -98.5795, coordinates?.lat || 39.8283],
      zoom: coordinates?.lat && coordinates?.lng ? 15 : 4
    });

    mapbox.on('load', () => {
      setIsLoading(false);
      setIsMapLoaded(true);

      // ✅ Draw polygon from step 1 if available
      if (polygonGeometry) {
        try {
          mapbox.addSource('property-polygon', {
            type: 'geojson',
            data: {
              type: 'Feature',
              geometry: polygonGeometry,
              properties: {}
            }
          });

          // Fill layer
          mapbox.addLayer({
            id: 'property-fill',
            type: 'fill',
            source: 'property-polygon',
            paint: { 
              'fill-color': '#329cf9', 
              'fill-opacity': 0.2 
            }
          });

          // Outline layer
          mapbox.addLayer({
            id: 'property-outline',
            type: 'line',
            source: 'property-polygon',
            paint: { 
              'line-color': '#329cf9', 
              'line-width': 3,
              'line-opacity': 0.8
            }
          });

          // Fit map to polygon bounds with maximum zoom
          fitGeometryTight(mapbox, polygonGeometry, {
            minPadPx: 5,   // minimal padding for maximum zoom
            marginPct: 0.01,
            maxZoom: 24
          });
          
          console.log('✅ Polygon from step 1 added to map successfully');
        } catch (err) {
          console.error('Error adding polygon from step 1:', err);
        }
      }

      // ✅ Draw parcel polygon if provided
      if (parcelWKT) {
        try {
          const geojson = wellknown(parcelWKT);
          if (geojson) {
            mapbox.addSource('parcel', {
              type: 'geojson',
              data: { type: 'Feature', geometry: geojson }
            });

            // Fill layer
            mapbox.addLayer({
              id: 'parcel-fill',
              type: 'fill',
              source: 'parcel',
              paint: { 'fill-color': '#00ff00', 'fill-opacity': 0.2 }
            });

            // Outline layer
            mapbox.addLayer({
              id: 'parcel-outline',
              type: 'line',
              source: 'parcel',
              paint: { 'line-color': '#006400', 'line-width': 2 }
            });

            // ✅ Handle Polygon vs MultiPolygon
            const coords =
              geojson.type === 'Polygon'
                ? geojson.coordinates[0]
                : geojson.coordinates[0][0];

            const bounds = new mapboxgl.LngLatBounds();
            coords.forEach(([lng, lat], index) => {
              bounds.extend([lng, lat]);
              const cornerMarker = new mapboxgl.Marker({ color: 'red' })
                .setLngLat([lng, lat])
                .setPopup(new mapboxgl.Popup().setText(`Corner ${index + 1}`))
                .addTo(mapbox);

              // Click action
              cornerMarker.getElement().addEventListener('click', () => {
                alert(`You clicked corner ${index + 1}`);
              });
            });
            
            // Fit map to parcel bounds with maximum zoom
            fitGeometryTight(mapbox, geojson, {
              minPadPx: 3,
              marginPct: 0.01,
              maxZoom: 22
            });
          }
        } catch (err) {
          console.error('Error parsing WKT:', err);
        }
      }
    });

    // Marker from coordinates
    if (coordinates?.lat && coordinates?.lng) {
      markerRef.current = new mapboxgl.Marker({ color: '#329cf9', scale: 1.2 })
        .setLngLat([coordinates.lng, coordinates.lat])
        .addTo(mapbox);
    }

    // Double click to place marker
    mapbox.on('dblclick', (e) => {
      const { lng, lat } = e.lngLat;
      setCoordinates({ lat, lng });
      if (markerRef.current) markerRef.current.remove();
      markerRef.current = new mapboxgl.Marker({ color: '#329cf9', scale: 1.2 })
        .setLngLat([lng, lat])
        .addTo(mapbox);
    });

    setMap(mapbox);

    return () => {
      if (markerRef.current) markerRef.current.remove();
      mapbox.remove();
      setIsMapLoaded(false);
    };
  }, []);

  // Update when coordinates change
  useEffect(() => {
    if (map && isMapLoaded && coordinates?.lat && coordinates?.lng) {
      map.flyTo({ center: [coordinates.lng, coordinates.lat], zoom: 17 });
      if (markerRef.current) markerRef.current.remove();
      markerRef.current = new mapboxgl.Marker({ color: '#329cf9', scale: 1.2 })
        .setLngLat([coordinates.lng, coordinates.lat])
        .addTo(map);
    }
  }, [coordinates, isMapLoaded, map]);

  // Geocode address
  const geocodeAddress = async () => {
    if (!address || !map) return;
    try {
      const response = await fetch(
        `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(
          address
        )}.json?access_token=${mapboxgl.accessToken}&limit=1`
      );
      const data = await response.json();
      if (data.features && data.features.length > 0) {
        const [lng, lat] = data.features[0].center;
        map.flyTo({ center: [lng, lat], zoom: 17 });
        setCoordinates({ lat, lng });
        if (markerRef.current) markerRef.current.remove();
        markerRef.current = new mapboxgl.Marker({ color: '#329cf9', scale: 1.2 })
          .setLngLat([lng, lat])
          .addTo(map);
      }
    } catch (error) {
      console.error('Geocoding error:', error);
    }
  };

  const resetMap = () => {
    if (map) {
      map.flyTo({ center: [-98.5795, 39.8283], zoom: 4 });
      if (markerRef.current) {
        markerRef.current.remove();
        markerRef.current = null;
      }
      setCoordinates({ lat: null, lng: null });
    }
  };

  if (!mapboxgl.accessToken) {
    return (
      <div className="w-full h-[80vh] flex items-center justify-center bg-gray-100 rounded-lg">
        <div className="text-center">
          <MapPin className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-700 mb-2">
            Mapbox Not Configured
          </h3>
          <p className="text-gray-500">
            Please add your Mapbox access token to use the map feature.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full flex flex-col gap-6">
      <div className="text-center">
        <h3 className="text-2xl font-bold text-gray-900 mb-2">
          📍 Pin Your Property Location
        </h3>
        <p className="text-gray-600">
          Double-click on the map to mark the exact location of your property
        </p>
      </div>

      <div className="flex flex-wrap gap-3 justify-center">
        {address && (
          <Button
            type="button"
            onClick={geocodeAddress}
            variant="outline"
            className="flex items-center gap-2"
          >
            <Navigation className="w-4 h-4" />
            Find Address on Map
          </Button>
        )}
        <Button
          type="button"
          onClick={resetMap}
          variant="outline"
          className="flex items-center gap-2"
        >
          <RotateCcw className="w-4 h-4" />
          Reset Map
        </Button>
      </div>

      <div className="relative w-full h-[70vh] rounded-xl overflow-hidden shadow-lg border border-gray-200">
        {isLoading && (
          <div className="absolute inset-0 bg-gray-100 flex items-center justify-center z-10">
            <div className="text-center">
              <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
              <p className="text-gray-600">Loading map...</p>
            </div>
          </div>
        )}
        <div ref={mapContainerRef} className="w-full h-full" />

        {coordinates?.lat && coordinates?.lng && (
          <div className="absolute bottom-4 left-4 bg-blue-600 text-white rounded-lg p-3 shadow-lg">
            <div className="text-sm font-medium">📍 Property Location</div>
            <div className="text-xs opacity-90">
              {coordinates.lat.toFixed(6)}, {coordinates.lng.toFixed(6)}
            </div>
          </div>
        )}
      </div>

      <div className="flex justify-between items-center pt-4 border-t border-gray-200">
        <Button
          type="button"
          onClick={onBack}
          variant="outline"
          className="flex items-center gap-2 px-6 py-3"
        >
          ← Back to Details
        </Button>

        <div className="text-center">
          <div className="text-sm text-gray-500 mb-1">Step 2 of 3</div>
          <div className="flex gap-2">
            <div className="w-8 h-2 bg-blue-600 rounded-full"></div>
            <div className="w-8 h-2 bg-blue-600 rounded-full"></div>
            <div className="w-8 h-2 bg-gray-200 rounded-full"></div>
          </div>
        </div>

        <Button
          type="button"
          onClick={() => {
            if (coordinates?.lat && coordinates?.lng) {
              onNext();
            } else {
              alert(
                'Please double-click on the map to mark your property location before continuing.'
              );
            }
          }}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 flex items-center gap-2"
          disabled={!coordinates?.lat || !coordinates?.lng}
        >
          Confirm Location →
        </Button>
      </div>
    </div>
  );
};

export default MapStep;
