@@ .. @@
        {/* Step 1: APN/Coordinates Input with AI Generator */}
        {currentStep === 1 && (
        )
        }
          <div className="space-y-8 bg-white rounded-2xl p-8">
            <div className="text-center">
@@ .. @@
        {/* Step 2: Map Pin Confirmation */}
        {currentStep === 2 && (
)
}
          <div className="space-y-6 bg-white rounded-2xl p-8">
            <div className="text-center">
@@ .. @@
        {/* Step 3: Manual Form to Edit Details */}
        {currentStep === 3 && (
)
}
          <div className="space-y-8 bg-white rounded-2xl p-8">
            <div className="text-center">
@@ .. @@
        {/* Step 4: Review Before Submission */}
        {currentStep === 4 && (
)
}
          <div className="space-y-8 bg-white rounded-2xl p-8">
            <div className="text-center">

    <div className="w-full max-w-6xl mx-auto">
      <Card className="bg-white shadow-2xl border-0 rounded-2xl overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
@@ .. @@
        </CardHeader>

        <CardContent className="p-8 pt-12">
          {error && (