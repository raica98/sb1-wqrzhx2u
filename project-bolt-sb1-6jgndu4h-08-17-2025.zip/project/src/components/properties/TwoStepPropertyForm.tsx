import React, { useState } from 'react';
import { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import axios from 'axios';
import mapboxgl from 'mapbox-gl';
import { useRef, useEffect } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { MapPin, Search, Loader2, ArrowRight, ArrowLeft, CheckCircle, Upload, X, Image as ImageIcon } from 'lucide-react';

// Mapbox configuration
const MAPBOX_ACCESS_TOKEN = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN || '';

// Set Mapbox access token
if (MAPBOX_ACCESS_TOKEN) {
  mapboxgl.accessToken = MAPBOX_ACCESS_TOKEN;
}

// Regrid API configuration
const REGRID_API_KEY = import.meta.env.VITE_REGRID_API_KEY || '';

// OpenAI API configuration
const OPENAI_API_KEY = import.meta.env.VITE_OPENAI_API_KEY || '';

// Step 1 schema - for APN or GPS input
const step1Schema = z.object({
  searchInput: z.string().min(1, 'Please enter an APN or GPS coordinates'),
});

// Step 2 schema - for the complete property form
const step2Schema = z.object({
  apn: z.string().min(1, 'APN is required'),
  title: z.string().min(5, 'Title must be at least 5 characters'),
  description: z.string().min(20, 'Description must be at least 20 characters'),
  price: z.number().min(1, 'Price must be greater than 0'),
  size_acres: z.number().min(0.1, 'Size must be at least 0.1 acres'),
  address: z.string().min(5, 'Address is required'),
  city: z.string().min(2, 'City is required'),
  state: z.string().min(2, 'State is required'),
  zip_code: z.string().min(5, 'ZIP code is required'),
  county: z.string().optional(),
  zoning: z.string().optional(),
  gps_coordinates: z.string().optional(),
});

type Step1Form = z.infer<typeof step1Schema>;
type Step2Form = z.infer<typeof step2Schema>;

interface RegridParcel {
  properties: {
    parcelnumb?: string;
    zoning?: string;
    zoning_description?: string;
    ll_gisacre?: number;
    deeded_acres?: number;
    gisacre?: number;
    address?: string;
    scity?: string;
    state2?: string;
    szip?: string;
    szip5?: string;
    county?: string;
    usedesc?: string;
  };
  geometry?: {
    coordinates?: number[][];
  };
}

interface RegridResponse {
  results?: RegridParcel[];
}

interface TwoStepPropertyFormProps {
  onSubmit: (data: Step2Form) => void;
  onClose: () => void;
  loading?: boolean;
}

export function TwoStepPropertyForm({ onSubmit, onClose, loading = false }: TwoStepPropertyFormProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [searchLoading, setSearchLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [propertyData, setPropertyData] = useState<Partial<Step2Form>>({});
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [coordinates, setCoordinates] = useState<{ lat: number | null; lng: number | null }>({ lat: null, lng: null });
  const [isMapLoaded, setIsMapLoaded] = useState(false);
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const marker = useRef<mapboxgl.Marker | null>(null);

  // Step 1 form
  const step1Form = useForm<Step1Form>({
    resolver: zodResolver(step1Schema),
  });

  // Step 2 form
  const step2Form = useForm<Step2Form>({
    resolver: zodResolver(step2Schema),
  });

  // Check if input is GPS coordinates (format: "lat, lon" or "lat,lon")
  const isGPSCoordinates = (input: string): boolean => {
    const coordPattern = /^-?\d+\.?\d*\s*,\s*-?\d+\.?\d*$/;
    return coordPattern.test(input.trim());
  };

  // Parse GPS coordinates from string
  const parseGPSCoordinates = (input: string): { lat: number; lon: number } | null => {
    try {
      const coords = input.split(',').map(coord => parseFloat(coord.trim()));
      if (coords.length === 2 && !isNaN(coords[0]) && !isNaN(coords[1])) {
        return { lat: coords[0], lon: coords[1] };
      }
    } catch (error) {
      console.error('Error parsing GPS coordinates:', error);
    }
    return null;
  };

  // Fetch property data from Regrid API
  const fetchRegridData = async (searchInput: string): Promise<RegridParcel | null> => {
    try {
      let url: string;
      
      if (isGPSCoordinates(searchInput)) {
        const coords = parseGPSCoordinates(searchInput);
        if (!coords) throw new Error('Invalid GPS coordinates format');
        
        url = `https://app.regrid.com/api/v1/parcels/nearest?lat=${coords.lat}&lon=${coords.lon}`;
      } else {
        // Treat as APN/parcel number
        url = `https://app.regrid.com/api/v1/parcels?parcelnumb=${encodeURIComponent(searchInput)}`;
      }

      const response = await axios.get(url, {
        headers: {
          'Authorization': `Bearer ${REGRID_API_KEY}`,
          'Content-Type': 'application/json'
        }
      });

      const data: RegridResponse = response.data;
      
      if (!data.results || data.results.length === 0) {
        throw new Error('No property found for the provided input');
      }

      return data.results[0];
    } catch (error) {
      console.error('Regrid API error:', error);
      throw error;
    }
  };

  // Generate title and description using OpenAI
  const generateTitleAndDescription = async (propertyInfo: any): Promise<{ title: string; description: string }> => {
    try {
      // Generate title
      const title = `${propertyInfo.size_acres || '1'}-Acre Property in ${propertyInfo.city || 'Unknown'}, ${propertyInfo.state || 'Unknown'}`;
      
      // Generate description using OpenAI
      const descriptionPrompt = `Write a short, professional property description for a vacant ${propertyInfo.size_acres || '1'}-acre lot in ${propertyInfo.city || 'Unknown'}, ${propertyInfo.county || 'Unknown'}, ${propertyInfo.state || 'Unknown'} with ${propertyInfo.zoning || 'residential'} zoning.`;
      
      const response = await axios.post('https://api.openai.com/v1/chat/completions', {
        model: 'gpt-4',
        messages: [
          { role: 'system', content: 'You are a real estate assistant helping write engaging property listings.' },
          { role: 'user', content: descriptionPrompt }
        ],
        max_tokens: 300,
        temperature: 0.7
      }, {
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        }
      });
      
      const description = response.data.choices[0]?.message?.content || 
        `Beautiful ${propertyInfo.size_acres || '1'}-acre property located in ${propertyInfo.city || 'Unknown'}, ${propertyInfo.county || 'Unknown'}, ${propertyInfo.state || 'Unknown'}. ${propertyInfo.zoning ? `Zoned ${propertyInfo.zoning}.` : ''} Great opportunity for development or investment.`;
      
      return { title, description };
    } catch (error) {
      console.error('OpenAI API error:', error);
      
      // Fallback if OpenAI fails
      const title = `${propertyInfo.size_acres || '1'}-Acre Property in ${propertyInfo.city || 'Unknown'}, ${propertyInfo.state || 'Unknown'}`;
      const description = `Beautiful ${propertyInfo.size_acres || '1'}-acre property located in ${propertyInfo.city || 'Unknown'}, ${propertyInfo.county || 'Unknown'}, ${propertyInfo.state || 'Unknown'}. ${propertyInfo.zoning ? `Zoned ${propertyInfo.zoning}.` : ''} Great opportunity for development or investment.`;
      
      return { title, description };
    }
  };

  // Handle Step 1 submission
  const handleStep1Submit = async (data: Step1Form) => {
    setSearchLoading(true);
    setSearchError(null);

    try {
      // Fetch data from Regrid
      const regridData = await fetchRegridData(data.searchInput);
      
      if (!regridData) {
        throw new Error('No property data found');
      }

      const props = regridData.properties;
      
      // Extract size in acres
      const sizeAcres = props.ll_gisacre || props.deeded_acres || props.gisacre || 1.0;
      
      // Extract GPS coordinates
      let gpsCoordinates = '';
      if (isGPSCoordinates(data.searchInput)) {
        gpsCoordinates = data.searchInput;
      } else if (regridData.geometry?.coordinates) {
        // Extract centroid from polygon coordinates if available
        const coords = regridData.geometry.coordinates[0];
        if (coords && coords.length > 0) {
          const lat = coords.reduce((sum, coord) => sum + coord[1], 0) / coords.length;
          const lon = coords.reduce((sum, coord) => sum + coord[0], 0) / coords.length;
          gpsCoordinates = `${lat.toFixed(6)}, ${lon.toFixed(6)}`;
        }
      }

      // Prepare property info for AI generation
      const propertyInfo = {
        size_acres: sizeAcres,
        city: props.scity || '',
        state: props.state2 || '',
        county: props.county || '',
        zoning: props.zoning || props.zoning_description || '',
        address: props.address || '',
      };

      // Generate title and description with AI
      setAiLoading(true);
      const { title, description } = await generateTitleAndDescription(propertyInfo);
      setAiLoading(false);

      // Populate property data
      const extractedData: Partial<Step2Form> = {
        apn: props.parcelnumb || data.searchInput,
        title,
        description,
        price: 50000, // Default price - user can modify
        size_acres: sizeAcres,
        address: props.address || '',
        city: props.scity || '',
        state: props.state2 || '',
        zip_code: props.szip || props.szip5 || '',
        county: props.county || '',
        zoning: props.zoning || props.zoning_description || '',
        gps_coordinates: gpsCoordinates,
      };

      setPropertyData(extractedData);
      
      // Populate Step 2 form
      step2Form.reset(extractedData as Step2Form);
      
      // Set coordinates for map
      if (gpsCoordinates) {
        const coords = parseGPSCoordinates(gpsCoordinates);
        if (coords) {
          setCoordinates({ lat: coords.lat, lng: coords.lon });
        }
      }
      
      // Move to Step 2
      setCurrentStep(2);
      
    } catch (error) {
      console.error('Error fetching property data:', error);
      setSearchError(error instanceof Error ? error.message : 'Failed to fetch property data');
    } finally {
      setSearchLoading(false);
      setAiLoading(false);
    }
  };

  // Image upload handling
  const onDrop = useCallback((acceptedFiles: File[]) => {
    acceptedFiles.forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        setUploadedImages(prev => [...prev, result]);
      };
      reader.readAsDataURL(file);
    });
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.webp']
    },
    maxFiles: 10
  });

  const removeImage = (index: number) => {
    setUploadedImages(prev => prev.filter((_, i) => i !== index));
  };

  // Initialize Mapbox map
  useEffect(() => {
    if (currentStep === 2 && mapContainer.current && MAPBOX_ACCESS_TOKEN && !map.current) {
      setIsMapLoaded(false);
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: 'mapbox://styles/mapbox/satellite-streets-v12',
        center: [coordinates.lng || -98.5795, coordinates.lat || 39.8283],
        zoom: coordinates.lat && coordinates.lng ? 15 : 4,
      });

      map.current.on('load', () => {
        setIsMapLoaded(true);
      });

      // Add existing marker if coordinates exist
      if (coordinates.lat && coordinates.lng) {
        marker.current = new mapboxgl.Marker({
          color: '#329cf9',
          scale: 1.2
        })
          .setLngLat([coordinates.lng, coordinates.lat])
          .addTo(map.current);
      }

      // Handle double-click to place marker
      map.current.on('dblclick', (e) => {
        const { lng, lat } = e.lngLat;
        setCoordinates({ lat, lng });

        // Remove existing marker
        if (marker.current) {
          marker.current.remove();
        }

        // Add new marker
        marker.current = new mapboxgl.Marker({
          color: '#329cf9',
          scale: 1.2
        })
          .setLngLat([lng, lat])
          .addTo(map.current!);

        // Update GPS coordinates in form
        step2Form.setValue('gps_coordinates', `${lat.toFixed(6)}, ${lng.toFixed(6)}`);
      });
    }

    return () => {
      if (marker.current) {
        marker.current.remove();
      }
      if (map.current) {
        map.current.remove();
        map.current = null;
        setIsMapLoaded(false);
      }
    };
  }, [currentStep]);

  // Update map center and marker when coordinates change
  useEffect(() => {
    if (map.current && isMapLoaded && coordinates.lat && coordinates.lng) {
      map.current.flyTo({ 
        center: [coordinates.lng, coordinates.lat], 
        zoom: 15 
      });

      if (marker.current) {
        marker.current.remove();
      }

      marker.current = new mapboxgl.Marker({
        color: '#329cf9',
        scale: 1.2
      })
        .setLngLat([coordinates.lng, coordinates.lat])
        .addTo(map.current);
    }
  }, [coordinates, isMapLoaded]);

  // Handle Step 2 submission
  const handleStep2Submit = (data: Step2Form) => {
    // Include uploaded images in the submission
    const finalData = {
      ...data,
      images: uploadedImages
    };
    onSubmit(finalData as Step2Form);
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <Card className="shadow-2xl border-0 rounded-2xl overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl font-bold">
              {currentStep === 1 ? '🔍 Find Property' : '📝 Property Details'}
            </CardTitle>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-colors"
            >
              ✕
            </button>
          </div>
          
          {/* Step Indicator */}
          <div className="flex items-center gap-4 mt-4">
            <div className={`flex items-center gap-2 ${currentStep >= 1 ? 'text-white' : 'text-white/50'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep >= 1 ? 'bg-white text-blue-600' : 'bg-white/20'}`}>
                {currentStep > 1 ? <CheckCircle className="w-5 h-5" /> : '1'}
              </div>
              <span className="font-medium">Search</span>
            </div>
            <div className="flex-1 h-0.5 bg-white/30"></div>
            <div className={`flex items-center gap-2 ${currentStep >= 2 ? 'text-white' : 'text-white/50'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep >= 2 ? 'bg-white text-blue-600' : 'bg-white/20'}`}>
                2
              </div>
              <span className="font-medium">Details</span>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-8">
          {currentStep === 1 && (
            <div className="space-y-6">
              <div className="text-center mb-8">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  Enter APN or GPS Coordinates
                </h3>
                <p className="text-gray-600">
                  We'll automatically fetch property details and generate a listing for you
                </p>
              </div>

              {searchError && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                  {searchError}
                </div>
              )}

              <form onSubmit={step1Form.handleSubmit(handleStep1Submit)} className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-gray-800 mb-3">
                    APN or GPS Coordinates *
                  </label>
                  <div className="relative">
                    <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <Input
                      {...step1Form.register('searchInput')}
                      placeholder="e.g., 123-456-789 or 32.8765, -96.8010"
                      className="pl-12 h-14 border-2 border-gray-200 rounded-xl focus:border-blue-500 text-lg"
                      disabled={searchLoading || aiLoading}
                    />
                  </div>
                  {step1Form.formState.errors.searchInput && (
                    <p className="text-red-600 text-sm mt-2">
                      {step1Form.formState.errors.searchInput.message}
                    </p>
                  )}
                  <p className="text-gray-500 text-sm mt-2">
                    💡 Enter an APN (Assessor's Parcel Number) or GPS coordinates (latitude, longitude)
                  </p>
                </div>

                <div className="flex justify-between">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={onClose}
                    disabled={searchLoading || aiLoading}
                    className="px-8"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={searchLoading || aiLoading}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8"
                  >
                    {searchLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Searching...
                      </>
                    ) : aiLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Generating listing...
                      </>
                    ) : (
                      <>
                        Search Property
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </div>
          )}

          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="text-center mb-8">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  Complete Property Details & Upload Images
                </h3>
                <p className="text-gray-600">
                  Review the auto-filled details, upload images, and pin the exact location
                </p>
              </div>

              <form onSubmit={step2Form.handleSubmit(handleStep2Submit)} className="space-y-6">
                {/* Image Upload Section */}
                <div className="space-y-4">
                  <h4 className="text-lg font-semibold text-gray-900 border-b pb-2 flex items-center gap-2">
                    <ImageIcon className="w-5 h-5" />
                    Property Images (up to 10)
                  </h4>
                  
                  {/* Image Upload */}
                  <div
                    {...getRootProps()}
                    className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-300 ${
                      isDragActive 
                        ? 'border-blue-500 bg-blue-50' 
                        : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50'
                    }`}
                  >
                    <input {...getInputProps()} />
                    <div className="space-y-3">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mx-auto">
                        <Upload className="w-6 h-6 text-white" />
                      </div>
                      {isDragActive ? (
                        <p className="text-blue-600 font-semibold">Drop the images here...</p>
                      ) : (
                        <div>
                          <p className="text-gray-700 font-semibold mb-1">
                            Drag & drop images here, or click to select
                          </p>
                          <p className="text-gray-500 text-sm">
                            Upload up to 10 high-quality images (JPEG, PNG, WebP)
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Image Preview Grid */}
                  {uploadedImages.length > 0 && (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {uploadedImages.map((image, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={image}
                            alt={`Upload ${index + 1}`}
                            className="w-full h-20 object-cover rounded-lg shadow-md group-hover:shadow-lg transition-shadow"
                          />
                          <Button
                            type="button"
                            onClick={() => removeImage(index)}
                            className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 hover:bg-red-600 text-white rounded-full p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Map Section */}
                {MAPBOX_ACCESS_TOKEN && (
                  <div className="space-y-4">
                    <h4 className="text-lg font-semibold text-gray-900 border-b pb-2 flex items-center gap-2">
                      <MapPin className="w-5 h-5" />
                      Property Location
                    </h4>
                    <div className="relative w-full h-64 rounded-xl overflow-hidden shadow-lg border border-gray-200">
                      <div ref={mapContainer} className="w-full h-full" />
                      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-lg">
                        <p className="text-sm text-gray-700 font-medium">
                          💡 <strong>Double-click</strong> on the map to pin the exact location
                        </p>
                      </div>
                      {coordinates.lat && coordinates.lng && (
                        <div className="absolute bottom-4 left-4 bg-blue-600 text-white rounded-lg p-3 shadow-lg">
                          <div className="text-sm font-medium">📍 Pinned Location</div>
                          <div className="text-xs opacity-90">
                            {coordinates.lat.toFixed(6)}, {coordinates.lng.toFixed(6)}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Basic Information */}
                <div className="space-y-4">
                  <h4 className="text-lg font-semibold text-gray-900 border-b pb-2">📋 Basic Information</h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-gray-800 mb-2">APN *</label>
                      <Input
                        {...step2Form.register('apn')}
                        className="h-12 border-2 border-gray-200 rounded-lg focus:border-blue-500"
                        readOnly
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-800 mb-2">Price ($) *</label>
                      <Input
                        {...step2Form.register('price', { valueAsNumber: true })}
                        type="number"
                        className="h-12 border-2 border-gray-200 rounded-lg focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-800 mb-2">Title *</label>
                    <Input
                      {...step2Form.register('title')}
                      className="h-12 border-2 border-gray-200 rounded-lg focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-800 mb-2">Description *</label>
                    <textarea
                      {...step2Form.register('description')}
                      className="w-full min-h-[120px] px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 resize-none"
                    />
                  </div>
                </div>

                {/* Property Details */}
                <div className="space-y-4">
                  <h4 className="text-lg font-semibold text-gray-900 border-b pb-2">🏗️ Property Details</h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-gray-800 mb-2">Size (acres) *</label>
                      <Input
                        {...step2Form.register('size_acres', { valueAsNumber: true })}
                        type="number"
                        step="0.1"
                        className="h-12 border-2 border-gray-200 rounded-lg focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-800 mb-2">Zoning</label>
                      <Input
                        {...step2Form.register('zoning')}
                        className="h-12 border-2 border-gray-200 rounded-lg focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-800 mb-2">GPS Coordinates</label>
                    <Input
                      {...step2Form.register('gps_coordinates')}
                      placeholder="e.g., 32.8765, -96.8010"
                      className="h-12 border-2 border-gray-200 rounded-lg focus:border-blue-500"
                    />
                  </div>
                </div>

                {/* Location Information */}
                <div className="space-y-4">
                  <h4 className="text-lg font-semibold text-gray-900 border-b pb-2">📍 Location Information</h4>
                  
                  <div>
                    <label className="block text-sm font-bold text-gray-800 mb-2">Address *</label>
                    <Input
                      {...step2Form.register('address')}
                      className="h-12 border-2 border-gray-200 rounded-lg focus:border-blue-500"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-gray-800 mb-2">City *</label>
                      <Input
                        {...step2Form.register('city')}
                        className="h-12 border-2 border-gray-200 rounded-lg focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-800 mb-2">State *</label>
                      <Input
                        {...step2Form.register('state')}
                        className="h-12 border-2 border-gray-200 rounded-lg focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-800 mb-2">ZIP Code *</label>
                      <Input
                        {...step2Form.register('zip_code')}
                        className="h-12 border-2 border-gray-200 rounded-lg focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-800 mb-2">County</label>
                    <Input
                      {...step2Form.register('county')}
                      className="h-12 border-2 border-gray-200 rounded-lg focus:border-blue-500"
                    />
                  </div>
                </div>

                <div className="flex justify-between pt-6 border-t">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setCurrentStep(1)}
                    disabled={loading}
                    className="px-8"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>
                  <Button
                    type="submit"
                    disabled={loading}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      'Create Listing'
                    )}
                  </Button>
                </div>
              </form>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}