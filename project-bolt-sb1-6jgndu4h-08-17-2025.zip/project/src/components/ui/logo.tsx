import React from 'react';

interface LogoProps {
  className?: string;
  width?: number;
  height?: number;
  showText?: boolean;
}

export function AcreageSaleLogo({ 
  className = "", 
  width = 120, 
  height = 40, 
  showText = true 
}: LogoProps) {
  return (
    <div className={`flex items-center ${className}`}>
      <svg
        width={showText ? width : height}
        height={height}
        viewBox="0 0 120 40"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="flex-shrink-0"
      >
        {/* Background gradient circle */}
        <defs>
          <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#329cf9" />
            <stop offset="50%" stopColor="#1e40af" />
            <stop offset="100%" stopColor="#1d4ed8" />
          </linearGradient>
          <linearGradient id="landGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#10b981" />
            <stop offset="100%" stopColor="#059669" />
          </linearGradient>
        </defs>
        
        {/* Main logo container */}
        <rect
          x="2"
          y="2"
          width="36"
          height="36"
          rx="8"
          fill="url(#logoGradient)"
          className="drop-shadow-lg"
        />
        
        {/* Land/Mountain silhouette */}
        <path
          d="M6 28 L12 18 L18 22 L24 16 L30 20 L34 24 L34 32 L6 32 Z"
          fill="url(#landGradient)"
          opacity="0.9"
        />
        
        {/* Property markers/pins */}
        <circle cx="12" cy="18" r="1.5" fill="white" opacity="0.9" />
        <circle cx="24" cy="16" r="1.5" fill="white" opacity="0.9" />
        <circle cx="30" cy="20" r="1.5" fill="white" opacity="0.9" />
        
        {/* Stylized "AS" letters */}
        <text
          x="20"
          y="26"
          fontSize="12"
          fontWeight="bold"
          fill="white"
          textAnchor="middle"
          fontFamily="system-ui, -apple-system, sans-serif"
          className="select-none"
        >
          AS
        </text>
        
        {/* Company name (if showText is true) */}
        {showText && (
          <>
            <text
              x="48"
              y="18"
              fontSize="14"
              fontWeight="700"
              fill="#1f2937"
              fontFamily="system-ui, -apple-system, sans-serif"
              className="select-none"
            >
              Acreage
            </text>
            <text
              x="48"
              y="32"
              fontSize="14"
              fontWeight="700"
              fill="#329cf9"
              fontFamily="system-ui, -apple-system, sans-serif"
              className="select-none"
            >
              Sale
            </text>
            
            {/* Tagline */}
            <text
              x="48"
              y="38"
              fontSize="6"
              fill="#6b7280"
              fontFamily="system-ui, -apple-system, sans-serif"
              className="select-none"
            >
              PREMIUM LAND MARKETPLACE
            </text>
          </>
        )}
      </svg>
    </div>
  );
}

// Compact version for headers
export function AcreageSaleLogoCompact({ className = "" }: { className?: string }) {
  return (
    <AcreageSaleLogo 
      className={className}
      width={40}
      height={40}
      showText={false}
    />
  );
}