import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Missing Supabase environment variables. Some features may not work.');
  // Don't throw error in production, just warn
}

// Create Supabase client with minimal configuration
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storage: typeof window !== 'undefined' ? localStorage : undefined,
    flowType: 'pkce'
  },
  global: {
    headers: {
      'x-client-info': 'acreage-sale-app'
    }
  },
  realtime: {
    params: {
      eventsPerSecond: 2
    }
  }
});

// Export Database type for TypeScript
export type Database = {
  public: {
    Tables: {
      properties: {
        Row: {
          id: string;
          user_id: string;
          title: string;
          description: string | null;
          price: number;
          size_acres: number;
          address: string;
          city: string;
          state: string;
          zip_code: string;
          county: string | null;
          apn: string | null;
          latitude: number | null;
          longitude: number | null;
          zoning: string | null;
          water: string | null;
          electricity: string | null;
          sewer: string | null;
          zoning: string | null;
          gps_coordinates: string | null;
          images: string[];
          status: string;
          created_at: string;
          updated_at: string;
          boundary_points: Array<{
            id: string;
            label: string;
            lat: number;
            lng: number;
          }> | null;
        };
        Insert: {
          id?: string;
          user_id: string;
          title: string;
          description?: string | null;
          price: number;
          size_acres: number;
          address: string;
          city: string;
          state: string;
          zip_code: string;
          county?: string | null;
          apn?: string | null;
          latitude?: number | null;
          longitude?: number | null;
          zoning?: string | null;
          water?: string | null;
          electricity?: string | null;
          sewer?: string | null;
          zoning?: string | null;
          gps_coordinates?: string | null;
          images?: string[];
          status?: string;
          created_at?: string;
          updated_at?: string;
          boundary_points?: Array<{
            id: string;
            label: string;
            lat: number;
            lng: number;
          }> | null;
        };
        Update: {
          id?: string;
          user_id?: string;
          title?: string;
          description?: string | null;
          price?: number;
          size_acres?: number;
          address?: string;
          city?: string;
          state?: string;
          zip_code?: string;
          county?: string | null;
          apn?: string | null;
          latitude?: number | null;
          longitude?: number | null;
          zoning?: string | null;
          water?: string | null;
          electricity?: string | null;
          sewer?: string | null;
          zoning?: string | null;
          gps_coordinates?: string | null;
          images?: string[];
          status?: string;
          created_at?: string;
          updated_at?: string;
          boundary_points?: Array<{
            id: string;
            label: string;
            lat: number;
            lng: number;
          }> | null;
        };
      };
      offers: {
        Row: {
          id: string;
          property_id: string;
          owner_id: string;
          buyer_name: string;
          buyer_email: string;
          buyer_phone: string;
          offer_amount: number;
          timeline: string | null;
          status: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          property_id: string;
          owner_id: string;
          buyer_name: string;
          buyer_email: string;
          buyer_phone: string;
          offer_amount: number;
          timeline?: string | null;
          status?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          property_id?: string;
          owner_id?: string;
          buyer_name?: string;
          buyer_email?: string;
          buyer_phone?: string;
          offer_amount?: number;
          timeline?: string | null;
          status?: string;
          created_at?: string;
        };
      };
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string | null;
          phone: string | null;
          disclaimer: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name?: string | null;
          phone?: string | null;
          disclaimer?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string | null;
          phone?: string | null;
          disclaimer?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
};