import React, { useMemo } from "react";
import { Link } from "react-router-dom";
import {
  ArrowLeft, MapPin, DollarSign, Ruler, TrendingUp, Users, Phone, Mail, Star, CheckCircle, ArrowRight
} from "lucide-react";
import { Button } from "../../components/ui/button";
import { Card, CardContent } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";

type Stat = { icon: React.ComponentType<any>; label: string; value: string; color: string };
type Testimonial = { name: string; role: string; content: string; rating: number };

type Props = {
  city?: string | null;
  state?: string | null;
  locationLabel?: string;   // e.g., "Dallas, Texas" or "New Jersey"
  searchQuery?: string;
  heroImage?: string;
  stats?: Partial<Record<"active"|"avg"|"acres"|"growth", string>>;
  benefits?: string[];
  testimonials?: Testimonial[];
  originalHtml?: string;     // <-- your original WP HTML goes here (unchanged)
  featured?: Array<{ title: string; location: string; price: string; acres: string; image: string }>;
};

export default function LandForSaleTemplate({
  city = null,
  state = null,
  locationLabel,
  searchQuery,
  heroImage,
  stats,
  benefits,
  testimonials,
  originalHtml,
  featured
}: Props) {

  const label = locationLabel || [city, state].filter(Boolean).join(", ");
  const query = searchQuery || (city || state || "").toString();

  const _stats: Stat[] = [
    { icon: MapPin,    label: "Active Listings",   value: stats?.active || "2,500+",  color: "text-blue-600"   },
    { icon: DollarSign,label: "Avg. Price/Acre",   value: stats?.avg    || "$15,000", color: "text-green-600"  },
    { icon: Ruler,     label: "Total Acres",       value: stats?.acres  || "50,000+", color: "text-purple-600" },
    { icon: TrendingUp,label: "Price Growth",      value: stats?.growth || "+12%",    color: "text-orange-600" }
  ];

  const _benefits = benefits || [
    "No realtor commissions - save 6%",
    "Direct owner negotiations",
    "Verified property data",
    "Professional aerial imagery",
    "Market analysis included",
    "Fast closing process"
  ];

  const _testimonials = testimonials || [
    {
      name: "Sarah Johnson",
      role: "Land Investor",
      content: `Found the perfect 10-acre plot in ${label} through Acreage Sale. The process was seamless and saved me thousands in fees.`,
      rating: 5
    },
    {
      name: "Mike Rodriguez",
      role: "Developer",
      content: `The market data and aerial imagery helped me make an informed decision. Closed on 25 acres in just 45 days.`,
      rating: 5
    }
  ];

  const fallbackHero = "https://images.pexels.com/photos/2462015/pexels-photo-2462015.jpeg?auto=compress&cs=tinysrgb&w=800";

  const defaultOriginalHtml = useMemo(() => {
    const body = `
      <div class="elementor elementor-default">
        <section class="elementor-section">
          <div class="elementor-container">
            <div class="elementor-column elementor-col-100">
              <div class="elementor-widget-wrap">
                <div class="elementor-widget elementor-widget-heading">
                  <div class="elementor-widget-container">
                    <h2 class="elementor-heading-title">Land for Sale in ${label}</h2>
                  </div>
                </div>
                <div class="elementor-widget elementor-widget-text-editor">
                  <div class="elementor-widget-container">
                    <p>${label} offers diverse opportunities across residential, commercial, industrial, and rural land.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>`;
    return body.trim();
  }, [label]);

  const _featured = featured || [
    {
      title: "25-Acre Development Site",
      location: city ? `North ${city}` : label,
      price: "$2,500,000",
      acres: "25.0",
      image: "https://images.pexels.com/photos/1115804/pexels-photo-1115804.jpeg?auto=compress&cs=tinysrgb&w=600"
    },
    {
      title: "Commercial Corner Lot",
      location: city ? `Downtown ${city}` : label,
      price: "$1,200,000",
      acres: "2.5",
      image: "https://images.pexels.com/photos/1370704/pexels-photo-1370704.jpeg?auto=compress&cs=tinysrgb&w=600"
    },
    {
      title: "Residential Development",
      location: city ? "Submarket" : label,
      price: "$850,000",
      acres: "5.2",
      image: "https://images.pexels.com/photos/1438832/pexels-photo-1438832.jpeg?auto=compress&cs=tinysrgb&w=600"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3 text-gray-600 hover:text-gray-900 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              <span className="font-medium">Back to Home</span>
            </Link>
            <Link to="/properties" className="text-blue-600 hover:text-blue-700 font-medium">
              View All Properties
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative py-20 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="bg-blue-100 text-blue-800 px-6 py-2 text-lg font-semibold mb-6">
              🏆 Premium Market
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              Land for Sale in <span className="text-blue-600 block">{label}</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed mb-8">
              Discover prime investment opportunities in one of America's most dynamic markets. 
              From residential development to commercial ventures, {label} offers exceptional potential.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to={`/properties?search=${encodeURIComponent(query)}`}>
                <Button className="bg-[#329cf9] hover:bg-[#2563eb] text-white px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all h-auto border-2 border-white">
                  Browse {city ? city : label} Properties
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50 px-8 py-4 text-lg font-semibold rounded-xl h-auto border-2">
                Get Market Analysis
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
            {_stats.map((stat, index) => (
              <Card key={index} className="text-center p-6 border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardContent className="p-0">
                  <div className={`w-12 h-12 ${stat.color.replace('text-', 'bg-').replace('-600', '-100')} rounded-xl flex items-center justify-center mx-auto mb-4`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
                  <div className="text-gray-600 text-sm font-medium">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Market Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Why {label} is a <span className="text-blue-600"> Prime Investment Market</span>
              </h2>
              <div className="space-y-6 text-lg text-gray-600 leading-relaxed">
                <p>Population growth and diversified employment continue to drive demand for land across {label}.</p>
                <p>Corporate expansion and infrastructure investment support long-term appreciation and development viability.</p>
                <p>Limited supply in key corridors, paired with strong demand, keeps the market competitive and resilient.</p>
              </div>
              
              <div className="mt-8 grid grid-cols-2 gap-6">
                <div className="text-center p-4 bg-blue-50 rounded-xl">
                  <div className="text-2xl font-bold text-blue-600">7.8M</div>
                  <div className="text-gray-700 font-medium">Metro Population</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-xl">
                  <div className="text-2xl font-bold text-green-600">$85B</div>
                  <div className="text-gray-700 font-medium">Annual GDP</div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img
                src={heroImage || fallbackHero}
                alt={`${label} skyline and development`}
                className="w-full h-96 object-cover rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-2xl"></div>
              <div className="absolute bottom-6 left-6 text-white">
                <div className="text-2xl font-bold mb-2">{label}</div>
                <div className="text-white/90">Prime Growth Market</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Why Choose Acreage Sale for {label} Land?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Skip traditional real estate hassles and connect directly with motivated sellers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {_benefits.map((benefit, index) => (
              <div key={index} className="flex items-center gap-4 p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <CheckCircle className="w-5 h-5 text-blue-600" />
                </div>
                <span className="text-gray-900 font-medium text-lg">{benefit}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Success Stories from {label} Investors
            </h2>
            <p className="text-xl text-gray-600">Real results from real investors</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {_testimonials.map((testimonial, index) => (
              <Card key={index} className="p-8 border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardContent className="p-0">
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <blockquote className="text-gray-700 text-lg leading-relaxed mb-6 italic">
                    "{testimonial.content}"
                  </blockquote>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <Users className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <div className="font-bold text-gray-900">{testimonial.name}</div>
                      <div className="text-gray-600">{testimonial.role}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-[#329cf9]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white drop-shadow-lg">
            Ready to Invest in {label} Land?
          </h2>
          <p className="text-xl text-white mb-8 max-w-2xl mx-auto drop-shadow-md font-semibold">
            Join thousands of successful investors who've found their perfect properties through our platform
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center mb-12">
            <Link to={`/properties?search=${encodeURIComponent(query)}`}>
              <Button className="bg-white text-[#329cf9] hover:bg-gray-100 hover:text-[#2563eb] px-8 py-4 text-lg font-bold rounded-xl shadow-xl hover:shadow-2xl transition-all h-auto border-2 border-white">
                Browse {city ? city : label} Properties
              </Button>
            </Link>
            <Button className="bg-transparent border-white border-2 text-white hover:bg-white hover:text-[#329cf9] px-8 py-4 text-lg font-bold rounded-xl h-auto shadow-xl hover:shadow-2xl transition-all">
              Get Free Market Report
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border-2 border-white">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <div className="font-bold text-white text-lg drop-shadow-md">Call Now</div>
                <div className="text-white text-base drop-shadow-sm font-semibold">949-767-8885</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border-2 border-white">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <div className="font-bold text-white text-lg drop-shadow-md">Email Us</div>
                <div className="text-white text-base drop-shadow-sm font-semibold">info@acreagesales.com</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Original WP Content */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-slate lg:prose-lg max-w-none">
            <div dangerouslySetInnerHTML={{ __html: (originalHtml || defaultOriginalHtml) }} />
          </div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Featured {label} Properties
            </h2>
            <p className="text-xl text-gray-600">
              Handpicked investment opportunities in prime locations
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {_featured.map((property, index) => (
              <Card key={index} className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
                <div className="relative">
                  <img
                    src={property.image}
                    alt={property.title}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-blue-600 text-white font-bold">
                      {property.acres} acres
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="font-bold text-xl text-gray-900 mb-2">{property.title}</h3>
                  <div className="flex items-center text-gray-600 mb-4">
                    <MapPin className="w-4 h-4 mr-2" />
                    <span>{property.location}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold text-blue-600">{property.price}</div>
                    <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <Link to={`/properties?search=${encodeURIComponent(query)}`}>
              <Button className="bg-[#329cf9] hover:bg-[#2563eb] text-white px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all border-2 border-white">
                View All {label} Properties
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
