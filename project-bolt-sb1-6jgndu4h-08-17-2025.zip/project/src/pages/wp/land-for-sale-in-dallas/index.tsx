import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, MapPin, DollarSign, Ruler, TrendingUp, Users, Phone, Mail, Star, CheckCircle, ArrowRight } from "lucide-react";
import { Button } from "../../../components/ui/button";
import { Card, CardContent } from "../../../components/ui/card";
import { Badge } from "../../../components/ui/badge";

export default function LandForSaleInDallasPage() {
  const stats = [
    { icon: MapPin, label: "Active Listings", value: "2,500+", color: "text-blue-600" },
    { icon: DollarSign, label: "Avg. Price/Acre", value: "$15,000", color: "text-green-600" },
    { icon: Ruler, label: "Total Acres", value: "50,000+", color: "text-purple-600" },
    { icon: TrendingUp, label: "Price Growth", value: "+12%", color: "text-orange-600" }
  ];

  const benefits = [
    "No realtor commissions - save 6%",
    "Direct owner negotiations",
    "Verified property data",
    "Professional aerial imagery",
    "Market analysis included",
    "Fast closing process"
  ];

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Land Investor",
      content: "Found the perfect 10-acre plot in Dallas through Acreage Sale. The process was seamless and saved me thousands in fees.",
      rating: 5
    },
    {
      name: "Mike Rodriguez", 
      role: "Developer",
      content: "The market data and aerial imagery helped me make an informed decision. Closed on 25 acres in just 45 days.",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3 text-gray-600 hover:text-gray-900 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              <span className="font-medium">Back to Home</span>
            </Link>
            <Link to="/properties" className="text-blue-600 hover:text-blue-700 font-medium">
              View All Properties
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="bg-blue-100 text-blue-800 px-6 py-2 text-lg font-semibold mb-6">
              🏆 Premium Market
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              Land for Sale in 
              <span className="text-blue-600 block">Dallas, Texas</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed mb-8">
              Discover prime investment opportunities in one of America's fastest-growing markets. 
              From residential development to commercial ventures, Dallas offers exceptional potential.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/properties?search=Dallas">
                <Button className="bg-[#329cf9] hover:bg-[#2563eb] text-white px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all h-auto border-2 border-white">
                  Browse Dallas Properties
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50 px-8 py-4 text-lg font-semibold rounded-xl h-auto border-2">
                Get Market Analysis
              </Button>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center p-6 border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardContent className="p-0">
                  <div className={`w-12 h-12 ${stat.color.replace('text-', 'bg-').replace('-600', '-100')} rounded-xl flex items-center justify-center mx-auto mb-4`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
                  <div className="text-gray-600 text-sm font-medium">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Market Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Why Dallas is a 
                <span className="text-blue-600"> Prime Investment Market</span>
              </h2>
              <div className="space-y-6 text-lg text-gray-600 leading-relaxed">
                <p>
                  Dallas-Fort Worth is experiencing unprecedented growth, with over 100,000 new residents 
                  annually. This population boom creates massive demand for housing and commercial development.
                </p>
                <p>
                  Major corporations like Toyota, Charles Schwab, and AT&T have relocated headquarters here, 
                  driving job growth and increasing land values across the metroplex.
                </p>
                <p>
                  With limited developable land and growing demand, property values have increased 12% 
                  year-over-year, making Dallas one of the strongest land investment markets in Texas.
                </p>
              </div>
              
              <div className="mt-8 grid grid-cols-2 gap-6">
                <div className="text-center p-4 bg-blue-50 rounded-xl">
                  <div className="text-2xl font-bold text-blue-600">7.8M</div>
                  <div className="text-gray-700 font-medium">Metro Population</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-xl">
                  <div className="text-2xl font-bold text-green-600">$85B</div>
                  <div className="text-gray-700 font-medium">Annual GDP</div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/2462015/pexels-photo-2462015.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Dallas skyline and development"
                className="w-full h-96 object-cover rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-2xl"></div>
              <div className="absolute bottom-6 left-6 text-white">
                <div className="text-2xl font-bold mb-2">Dallas-Fort Worth Metroplex</div>
                <div className="text-white/90">America's 4th Largest Metro Area</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Why Choose Acreage Sale for Dallas Land?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Skip traditional real estate hassles and connect directly with motivated sellers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-center gap-4 p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <CheckCircle className="w-5 h-5 text-blue-600" />
                </div>
                <span className="text-gray-900 font-medium text-lg">{benefit}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Success Stories from Dallas Investors
            </h2>
            <p className="text-xl text-gray-600">
              Real results from real investors in the Dallas market
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="p-8 border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardContent className="p-0">
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <blockquote className="text-gray-700 text-lg leading-relaxed mb-6 italic">
                    "{testimonial.content}"
                  </blockquote>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <Users className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <div className="font-bold text-gray-900">{testimonial.name}</div>
                      <div className="text-gray-600">{testimonial.role}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#329cf9]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white drop-shadow-lg">
            Ready to Invest in Dallas Land?
          </h2>
          <p className="text-xl text-white mb-8 max-w-2xl mx-auto drop-shadow-md font-semibold">
            Join thousands of successful investors who've found their perfect properties through our platform
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center mb-12">
            <Link to="/properties?search=Dallas">
              <Button className="bg-white text-[#329cf9] hover:bg-gray-100 hover:text-[#2563eb] px-8 py-4 text-lg font-bold rounded-xl shadow-xl hover:shadow-2xl transition-all h-auto border-2 border-white">
                Browse Dallas Properties
              </Button>
            </Link>
            <Button className="bg-transparent border-white border-2 text-white hover:bg-white hover:text-[#329cf9] px-8 py-4 text-lg font-bold rounded-xl h-auto shadow-xl hover:shadow-2xl transition-all">
              Get Free Market Report
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border-2 border-white">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <div className="font-bold text-white text-lg drop-shadow-md">Call Now</div>
                <div className="text-white text-base drop-shadow-sm font-semibold">949-767-8885</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border-2 border-white">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <div className="font-bold text-white text-lg drop-shadow-md">Email Us</div>
                <div className="text-white text-base drop-shadow-sm font-semibold">info@acreagesales.com</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Original Content Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-slate lg:prose-lg max-w-none">
            <div dangerouslySetInnerHTML={{
              __html: `
                <div data-elementor-type="wp-page" data-elementor-id="20963" class="elementor elementor-20963">
                  <section class="elementor-section elementor-top-section elementor-element elementor-element-b9132f8 elementor-section-stretched elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="b9132f8" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
                    <div class="elementor-container elementor-column-gap-default">
                      <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b8b8b8b" data-id="b8b8b8b" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                          <div class="elementor-element elementor-element-c9c9c9c elementor-widget elementor-widget-heading" data-id="c9c9c9c" data-element_type="widget" data-widget_type="heading.default">
                            <div class="elementor-widget-container">
                              <h2 class="elementor-heading-title elementor-size-default">Land for Sale in Dallas</h2>
                            </div>
                          </div>
                          <div class="elementor-element elementor-element-d1d1d1d elementor-widget elementor-widget-text-editor" data-id="d1d1d1d" data-element_type="widget" data-widget_type="text-editor.default">
                            <div class="elementor-widget-container">
                              <p>Dallas, Texas, is a thriving metropolis with a booming real estate market. Whether you're looking to invest in residential development, commercial ventures, or agricultural land, Dallas offers diverse opportunities for land buyers.</p>
                              <h3>Why Invest in Dallas Land?</h3>
                              <ul>
                                <li><strong>Economic Growth:</strong> Dallas is home to numerous Fortune 500 companies and continues to attract businesses and residents.</li>
                                <li><strong>Population Boom:</strong> The Dallas-Fort Worth metroplex is one of the fastest-growing regions in the United States.</li>
                                <li><strong>Infrastructure Development:</strong> Ongoing infrastructure projects enhance property values and accessibility.</li>
                                <li><strong>Diverse Economy:</strong> From technology to energy, Dallas has a robust and diversified economic base.</li>
                              </ul>
                              <h3>Types of Land Available</h3>
                              <p>In Dallas, you can find various types of land for sale:</p>
                              <ul>
                                <li><strong>Residential Development Land:</strong> Perfect for housing projects, subdivisions, and single-family homes.</li>
                                <li><strong>Commercial Land:</strong> Ideal for retail centers, office buildings, and mixed-use developments.</li>
                                <li><strong>Industrial Land:</strong> Suitable for warehouses, manufacturing facilities, and logistics centers.</li>
                                <li><strong>Agricultural Land:</strong> Great for farming, ranching, and rural development projects.</li>
                              </ul>
                              <h3>Investment Considerations</h3>
                              <p>When investing in Dallas land, consider the following factors:</p>
                              <ul>
                                <li><strong>Location:</strong> Proximity to major highways, airports, and city centers affects land value.</li>
                                <li><strong>Zoning:</strong> Understanding zoning regulations is crucial for your intended use.</li>
                                <li><strong>Utilities:</strong> Access to water, electricity, and sewer systems impacts development costs.</li>
                                <li><strong>Future Development:</strong> Research planned infrastructure and development projects in the area.</li>
                              </ul>
                              <h3>Getting Started</h3>
                              <p>Ready to explore land opportunities in Dallas? Our platform connects you directly with property owners, eliminating middleman fees and providing transparent pricing. Browse our current listings or contact our team for personalized assistance in finding the perfect land for your investment goals.</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                </div>
              `.trim()
            }} />
          </div>
        </div>
      </section>

      {/* Featured Properties Preview */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Featured Dallas Properties
            </h2>
            <p className="text-xl text-gray-600">
              Handpicked investment opportunities in prime Dallas locations
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {[
              {
                title: "25-Acre Development Site",
                location: "North Dallas",
                price: "$2,500,000",
                acres: "25.0",
                image: "https://images.pexels.com/photos/1115804/pexels-photo-1115804.jpeg?auto=compress&cs=tinysrgb&w=600"
              },
              {
                title: "Commercial Corner Lot",
                location: "Downtown Dallas",
                price: "$1,200,000",
                acres: "2.5",
                image: "https://images.pexels.com/photos/1370704/pexels-photo-1370704.jpeg?auto=compress&cs=tinysrgb&w=600"
              },
              {
                title: "Residential Development",
                location: "Plano",
                price: "$850,000",
                acres: "5.2",
                image: "https://images.pexels.com/photos/1438832/pexels-photo-1438832.jpeg?auto=compress&cs=tinysrgb&w=600"
              }
            ].map((property, index) => (
              <Card key={index} className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
                <div className="relative">
                  <img
                    src={property.image}
                    alt={property.title}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-blue-600 text-white font-bold">
                      {property.acres} acres
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="font-bold text-xl text-gray-900 mb-2">{property.title}</h3>
                  <div className="flex items-center text-gray-600 mb-4">
                    <MapPin className="w-4 h-4 mr-2" />
                    <span>{property.location}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold text-blue-600">{property.price}</div>
                    <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <Link to="/properties?search=Dallas">
              <Button className="bg-[#329cf9] hover:bg-[#2563eb] text-white px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all border-2 border-white">
                View All Dallas Properties
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}