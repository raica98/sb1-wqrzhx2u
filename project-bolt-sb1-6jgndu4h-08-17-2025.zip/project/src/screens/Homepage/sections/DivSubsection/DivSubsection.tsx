import React from "react";
import { Button } from "../../../../components/ui/button";
import { ArrowRight, CheckCircle, Phone, Mail, Clock, Shield, DollarSign, Zap } from "lucide-react";

export const DivSubsection = (): JSX.Element => {
  return (
    <section className="w-full py-20 bg-white relative overflow-hidden">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          {/* Left side with content */}
          <div className="w-full lg:w-1/2 space-y-8">
            <div className="space-y-6">
              <div className="inline-flex items-center bg-[#329cf9]/10 text-[#329cf9] px-6 py-3 rounded-full font-semibold text-sm border border-[#329cf9]/20">
                <Zap className="w-4 h-4 mr-2" />
                Fast Cash Solutions
              </div>
              
              <h2 className="text-4xl lg:text-5xl font-bold leading-tight text-gray-900">
                Need to sell your land 
                <span className="text-[#329cf9]">fast?</span>
              </h2>
              
              <div className="w-24 h-1 bg-[#329cf9] rounded-full"></div>
            </div>

            <p className="text-xl text-gray-600 leading-relaxed">
              Skip the hassle of traditional real estate. We buy land cash with our own money! 
              Get cash offers, fast closings, and zero fees from our experienced team.
            </p>
            
            {/* Benefits grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { icon: Clock, title: "24-Hour Cash Offers", desc: "Get your offer within one business day" },
                { icon: Shield, title: "Any Condition", desc: "We buy land as-is, no repairs needed" },
                { icon: DollarSign, title: "Zero Fees", desc: "No commissions or hidden costs" },
                { icon: Zap, title: "Fast Closing", desc: "Close in 30-60 days guaranteed" }
              ].map((benefit, index) => (
                <div key={index} className="flex items-start gap-4 p-6 bg-gray-50 rounded-xl border border-gray-200">
                  <div className="w-12 h-12 bg-[#329cf9]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <benefit.icon className="w-6 h-6 text-[#329cf9]" />
                  </div>
                  <div>
                    <h3 className="text-gray-900 font-bold text-lg mb-2">{benefit.title}</h3>
                    <p className="text-gray-600 text-sm">{benefit.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-6">
              <Button className="bg-[#329cf9] hover:bg-[#329cf9]/90 text-white px-10 py-6 min-h-[56px] rounded-2xl font-bold text-xl shadow-lg hover:shadow-xl transition-all duration-300 group">
                Get My Cash Offer Now
                <ArrowRight className="w-6 h-6 ml-3 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>

            {/* Contact info */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6 pt-8 border-t border-gray-200">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-[#329cf9]/10 rounded-full flex items-center justify-center">
                  <Phone className="w-6 h-6 text-[#329cf9]" />
                </div>
                <div>
                  <div className="text-gray-900 font-bold">Call Now</div>
                  <div className="text-gray-600">949-767-8885</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-[#329cf9]/10 rounded-full flex items-center justify-center">
                  <Mail className="w-6 h-6 text-[#329cf9]" />
                </div>
                <div>
                  <div className="text-gray-900 font-bold">Email Us</div>
                  <div className="text-gray-600">info@acreagesales.com</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right side with visual elements */}
          <div className="w-full lg:w-1/2 relative">
            <div className="relative">
              {/* Main card */}
              <div className="bg-white rounded-3xl p-8 shadow-2xl border border-gray-200">
                <div className="text-center mb-8">
                  <div className="w-20 h-20 bg-gradient-to-r from-[#329cf9] to-[#329cf9]/80 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <DollarSign className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">Cash Offer Process</h3>
                  <p className="text-gray-600">Simple, fast, and transparent</p>
                </div>
                
                <div className="space-y-6">
                  {[
                    { step: "1", title: "Submit Property Info", time: "2 minutes" },
                    { step: "2", title: "Receive Cash Offer", time: "24 hours" },
                    { step: "3", title: "Accept & Close", time: "30-60 days" }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
                      <div className="w-10 h-10 bg-[#329cf9] rounded-full flex items-center justify-center text-white font-bold flex-shrink-0">
                        {item.step}
                      </div>
                      <div className="flex-1">
                        <div className="font-semibold text-gray-900">{item.title}</div>
                        <div className="text-gray-600 text-sm">{item.time}</div>
                      </div>
                      <CheckCircle className="w-6 h-6 text-green-500" />
                    </div>
                  ))}
                </div>
                
                <div className="mt-8 p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl border border-green-200">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600 mb-2">$2.5M+</div>
                    <div className="text-green-700 font-medium">Paid to Land Owners</div>
                    <div className="text-green-600 text-sm mt-1">This year alone</div>
                  </div>
                </div>
              </div>
              
              {/* Floating testimonial */}
              <div className="absolute -top-6 -right-6 bg-white rounded-2xl p-6 shadow-xl border border-gray-100 max-w-[280px] z-10">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-[#329cf9] to-[#329cf9]/80 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold">SM</span>
                  </div>
                  <div>
                    <div className="font-bold text-gray-900">Sarah M.</div>
                    <div className="text-sm text-gray-600">Land Owner</div>
                  </div>
                </div>
                <p className="text-sm text-gray-700 italic">
                  "Got my cash offer in 18 hours and closed in 45 days. Amazing service!"
                </p>
                <div className="flex text-yellow-400 mt-3">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className="text-lg">★</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};