import React from "react";
import { useAuth } from "../../../../hooks/useAuth";

export const Group2Subsection = (): JSX.Element => {
  const { user } = useAuth();
  
  return (
    <></>
  );
};