import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "../../../../components/ui/accordion";

export const Group3Subsection = (): JSX.Element => {
  const accordionItems = [
    {
      id: "item-1",
      trigger: "YOUR WAY THROUGH THE BEST LAND CONTRACTS!",
      content:
        "There isn't one but many options that you have to make an investment in. From the difference in the locations to the potentiality of different lands, it is always a good idea to walk as per professional advice. Hiring real estate agents can keep you invested in the right deal. So, have a land of yielding opportunities and convenience by having the support of the best real estate service at Acreage Sale. Garner your investment choice with the top-notch counsel of experts who can get you secure and profitable deals in your budget.",
      defaultOpen: true,
    },
    {
      id: "item-2",
      trigger: "ABOUT ACREAGE SALE",
      content: "",
      defaultOpen: false,
    },
  ];

  return (
    <section className="w-full max-w-[1422px] mx-auto py-16 flex flex-col md:flex-row gap-12">
      {/* Left side with images */}
      <div className="w-full md:w-1/2 relative">
        <div className="relative h-full">
          <div className="relative">
            <img
              className="w-full max-w-[500px] h-[555px] object-cover"
              alt="Property image"
            />
            <div className="absolute bottom-0 right-0 w-[340px] h-[450px] bg-white">
              <img
                className="m-5 w-80 h-[430px] object-cover"
                alt="Property detail"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Right side with content */}
      <div className="w-full md:w-1/2 flex flex-col gap-12">
        {/* Heading */}
        <h2 className="font-['DM_Serif_Text',Helvetica] text-4xl">
          <span className="text-[#343d42]">
            ROUND-THE-CLOCK SUPPORT FROM THE MOST ELIGIBLE AND{" "}
          </span>
          <span className="text-blue">COMPETENT DOMAIN PROFESSIONALS!</span>
        </h2>

        {/* Accordion */}
        <Accordion type="single" collapsible className="w-full">
          {accordionItems.map((item) => (
            <AccordionItem
              key={item.id}
              value={item.id}
              className={`mb-4 rounded-[10px] border border-solid ${
                item.defaultOpen
                  ? "border-blue shadow-[0px_14px_34px_#00000012]"
                  : "border-[#cfcfcf]"
              }`}
            >
              <AccordionTrigger className="px-7 py-6">
                <span className="font-semibold text-dark text-xl">
                  {item.trigger}
                </span>
              </AccordionTrigger>
              <AccordionContent>
                <div className="px-7 pb-6">
                  <p className="text-[#898f97] text-base leading-[26px]">
                    {item.content}
                  </p>
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
};
