import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const Group4Subsection = (): JSX.Element => {
  const features = [
    {
      title: "100% Bonafide list",
      icon: (
        <img className="w-[35px] h-[45px] mx-auto" alt="Bonafide list icon" />
      ),
    },
    {
      title: "Best Offer",
      icon: (
        <div className="relative h-10 w-[46px] mx-auto">
          <img
            className="absolute w-[31px] h-[38px] top-0 left-[15px]"
            alt="Best offer icon"
            src="/vector-9.svg"
          />
          <img
            className="absolute w-3 h-[23px] top-[17px] left-0"
            alt="Best offer detail"
            src="/vector-13.svg"
          />
        </div>
      ),
    },
    {
      title: "One- up Support",
      icon: <img className="w-10 h-10 mx-auto" alt="Support icon" />,
    },
  ];

  return (
    <section className="relative w-full py-8 bg-cover bg-center">
      <Card className="max-w-[1417px] mx-auto border-none">
        <CardContent className="p-0">
          <div className="relative w-full md:w-[523px] p-8">
            <div className="mb-8">
              <h2 className="font-serif text-4xl mb-4">
                <span className="text-white">The land </span>
                <span className="text-blue">marketplace</span>
              </h2>
              <div className="w-[50px] h-[5px] bg-white rounded-[3px]" />
            </div>

            <p className="text-white text-lg leading-[26px] mb-10 max-w-[521px]">
              Welcome to the top marketplace to buy and sell land online.
              Explore where to buy land for sale and watch for small empty lots,
              country homes, farm tracts, large recreational properties, and
              homesites.
            </p>

            <div className="flex flex-wrap gap-8">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className="flex flex-col items-center w-[163px]"
                >
                  <div className="mb-6">{feature.icon}</div>
                  <p className="text-white text-xl font-medium text-center whitespace-nowrap">
                    {feature.title}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  );
};
