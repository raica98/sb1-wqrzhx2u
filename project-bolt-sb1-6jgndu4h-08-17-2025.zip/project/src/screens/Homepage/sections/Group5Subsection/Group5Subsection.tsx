import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const Group5Subsection = (): JSX.Element => {
  const landHuntingTips = [
    {
      number: "1",
      title: "Be location specific while conducting your research",
      description:
        "You must be quite clear about why you want to buy the land and where you want to do so. It is essential to have a fundamental understanding of the property you desire...",
    },
    {
      number: "2",
      title: "Give no thought to receiving reviews",
      description:
        "Getting some reviews is always a good idea before moving further. To fully understand the kind of life and opportunities that land offers, you should speak with the existing landowners.",
    },
    {
      number: "3",
      title: "Learn about natural regeneration's range.",
      description:
        "Before making an investment, it is essential to comprehend the land's potential. Here, you must ensure that the land in which you are investing is rich in possibilities and...",
    },
  ];

  return (
    <section className="w-full py-16 relative">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Left side with heading */}
          <div className="lg:w-1/3">
            <div className="mb-8">
              <h2 className="font-['DM_Serif_Text',Helvetica] text-4xl leading-normal">
                <span className="text-[#010101]">
                  LAND HUNTING DONE RIGHT:{" "}
                </span>
                <span className="text-[#329df9]">HOW TO PROCEED</span>
              </h2>
            </div>
            <div className="w-[110px] h-[45px] mb-4"></div>
          </div>

          {/* Right side with cards */}
          <div className="lg:w-2/3">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {landHuntingTips.map((tip, index) => (
                <Card
                  key={index}
                  className="rounded shadow-[0px_4px_44px_#00000012] overflow-hidden"
                >
                  <div className="h-[395px] bg-[#cfcfcf] opacity-80"></div>
                  <CardContent className="p-5">
                    <h3 className="font-['Inter',Helvetica] font-medium text-black text-[22px] leading-[30px] mb-4">
                      {tip.number}. {tip.title}
                    </h3>
                    <p className="font-['Inter',Helvetica] font-normal text-[#7c7e83] text-base leading-[26px]">
                      {tip.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="flex justify-center mt-8">
              <div className="w-[150px] h-[3px] bg-[#329df9]"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
