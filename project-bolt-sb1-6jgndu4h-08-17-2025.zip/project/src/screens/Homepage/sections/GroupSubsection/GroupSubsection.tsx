import { SearchIcon } from "lucide-react";
import React from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Badge } from "../../../../components/ui/badge";
import { Button } from "../../../../components/ui/button";
import { Input } from "../../../../components/ui/input";

export const GroupSubsection = (): JSX.Element => {
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();
  const [currentFeature, setCurrentFeature] = useState(0);

  const features = [
    "AI Auto-Listing saves hours to days of work",
    "Market Analyzer shows hottest investment areas",
    "Buyer Backtesting reveals 10-year ROI potential",
    "Custom Land Consulting for development scenarios"
  ];

  // Rotate features every 3 seconds
  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentFeature((prev) => (prev + 1) % features.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      // Navigate to properties page with search term as URL parameter
      navigate(`/properties?search=${encodeURIComponent(searchTerm.trim())}`);
    } else {
      // Navigate to properties page without search term
      navigate('/properties');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSearch(e as any);
    }
  };

  return (
    <section className="w-full pb-16 sm:pb-20 lg:pb-28 flex flex-col items-center relative overflow-hidden bg-gray-50 min-h-screen">
      {/* Badge */}
      <div className="relative mb-8 sm:mb-12 z-10 mt-12">
        <Badge
          variant="outline"
          className="bg-white text-[#329cf9] border-[#329cf9] font-semibold text-sm sm:text-base px-6 sm:px-8 py-3 shadow-lg hover:shadow-xl transition-all duration-300 rounded-full flex items-center gap-2"
        >
          <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: '#329cf9' }}></div>
          #1 Land Wholesaling Marketplace
        </Badge>
      </div>

      {/* Search bar */}
      <div className="w-full max-w-2xl px-4 mb-8">
        <form onSubmit={handleSearch} className="flex items-center shadow-lg rounded-lg overflow-hidden bg-white border border-gray-200">
          <div className="relative flex-grow">
            <SearchIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyDown={handleKeyPress}
              className="pl-12 h-12 bg-white border-0 font-medium text-base focus:ring-0 focus:outline-none placeholder:text-gray-400 rounded-l-lg"
              placeholder="Search by location"
              autoComplete="off"
            />
          </div>
          <Button 
            type="submit"
            className="h-12 px-8 bg-[#329cf9] hover:bg-[#2563eb] text-white font-semibold text-base border-0 transition-all duration-300 hover:shadow-lg rounded-r-lg"
          >
            Search
          </Button>
        </form>
      </div>

      {/* Description */}
      <div className="text-center mb-12 px-4">
        <p className="text-gray-600 text-lg max-w-3xl mx-auto leading-relaxed">
          Revolutionary AI platform that automates land listing, provides market analysis, 
          backtesting tools, and custom consulting to maximize your investment returns!
        </p>
      </div>

      {/* Center Image */}
      <div className="flex justify-center mb-8">
        <img
          src="http://pacificlandbuyers.com/wp-content/uploads/2025/07/output-onlinepngtools-scaled.png"
          alt="Land investment opportunities"
          className="max-w-full h-auto object-contain"
        />
      </div>

      {/* AI Investment Intelligence Section */}
      <div className="w-full max-w-4xl mx-auto px-4 mb-12">
        <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/20">
          <h4 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3 justify-center">
            We put the land owner in the drivers seat!
          </h4>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-[#329cf9]/10 rounded-xl border border-[#329cf9]/30">
              <span className="font-medium text-gray-900">Auto-Listing Generator</span>
              <span className="text-[#329cf9] font-bold">Active</span>
            </div>
            <div className="flex items-center justify-between p-4 bg-[#329cf9]/10 rounded-xl border border-[#329cf9]/30">
              <span className="font-medium text-gray-900">Market Analyzer</span>
              <span className="text-[#329cf9] font-bold">Live</span>
            </div>
            <div className="flex items-center justify-between p-4 bg-[#329cf9]/10 rounded-xl border border-[#329cf9]/30">
              <span className="font-medium text-gray-900">ROI Backtesting</span>
              <span className="text-[#329cf9] font-bold">Ready</span>
            </div>
            <div className="flex items-center justify-between p-4 bg-[#329cf9]/10 rounded-xl border border-[#329cf9]/30">
              <span className="font-medium text-gray-900">Custom Consulting</span>
              <span className="text-[#329cf9] font-bold">Available</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};