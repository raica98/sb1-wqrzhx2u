import React from "react";
import { AspectRatio } from "../../../../components/ui/aspect-ratio";
import { Card, CardContent } from "../../../../components/ui/card";

export const OverlapWrapperSubsection = (): JSX.Element => {
  // Data for circular text letters
  const circularTextLetters = [
    {
      top: "top-[131px]",
      left: "left-[59px]",
      rotate: "rotate-[-171.04deg]",
      text: "s",
    },
    {
      top: "top-32",
      left: "left-[46px]",
      rotate: "rotate-[-159.53deg]",
      text: "a",
    },
    {
      top: "top-[122px]",
      left: "left-[37px]",
      rotate: "rotate-[-149.11deg]",
      text: "l",
    },
    {
      top: "top-[30px]",
      left: "left-6",
      rotate: "rotate-[-138.69deg]",
      text: "e",
    },
    {
      top: "top-[22px]",
      left: "left-[18px]",
      rotate: "rotate-[-128.28deg]",
      text: "",
    },
    {
      top: "top-[11px]",
      left: "left-[9px]",
      rotate: "rotate-[-117.86deg]",
      text: "y",
    },
    {
      top: "top-[-1px]",
      left: "left-1",
      rotate: "rotate-[-105.80deg]",
      text: "o",
    },
    {
      top: "top-[34px]",
      left: "left-[3px]",
      rotate: "rotate-[-93.74deg]",
      text: "u",
    },
    {
      top: "top-[21px]",
      left: "left-[5px]",
      rotate: "rotate-[-82.78deg]",
      text: "r",
    },
    {
      top: "top-[11px]",
      left: "left-2",
      rotate: "rotate-[-73.46deg]",
      text: "",
    },
    { top: "top-0", left: "left-2.5", rotate: "rotate-[-63.04deg]", text: "L" },
    {
      top: "top-0",
      left: "left-[18px]",
      rotate: "rotate-[-50.98deg]",
      text: "a",
    },
    {
      top: "top-px",
      left: "left-[27px]",
      rotate: "rotate-[-38.92deg]",
      text: "n",
    },
    {
      top: "top-[7px]",
      left: "left-[39px]",
      rotate: "rotate-[-26.86deg]",
      text: "d",
    },
    {
      top: "top-[3px]",
      left: "left-[52px]",
      rotate: "rotate-[-16.45deg]",
      text: "",
    },
    {
      top: "top-0",
      left: "left-[62px]",
      rotate: "rotate-[-4.93deg]",
      text: "w",
    },
    {
      top: "top-0",
      left: "left-[78px]",
      rotate: "rotate-[6.58deg]",
      text: "i",
    },
    {
      top: "top-0.5",
      left: "left-[88px]",
      rotate: "rotate-[15.90deg]",
      text: "t",
    },
    {
      top: "top-[7px]",
      left: "left-[98px]",
      rotate: "rotate-[26.86deg]",
      text: "h",
    },
    {
      top: "top-[13px]",
      left: "left-[110px]",
      rotate: "rotate-[37.28deg]",
      text: "",
    },
    { top: "top-0", left: "left-1", rotate: "rotate-[47.69deg]", text: "a" },
    { top: "top-0", left: "left-1", rotate: "rotate-[59.75deg]", text: "c" },
    {
      top: "top-[11px]",
      left: "left-2.5",
      rotate: "rotate-[70.72deg]",
      text: "r",
    },
    {
      top: "top-[23px]",
      left: "left-3",
      rotate: "rotate-[81.68deg]",
      text: "e",
    },
    {
      top: "top-[70px]",
      left: "left-[134px]",
      rotate: "rotate-[93.74deg]",
      text: "a",
    },
    {
      top: "top-[-1px]",
      left: "left-[9px]",
      rotate: "rotate-[105.80deg]",
      text: "g",
    },
    { top: "top-3", left: "left-1", rotate: "rotate-[117.86deg]", text: "e" },
    {
      top: "top-[21px]",
      left: "left-[5px]",
      rotate: "rotate-[128.28deg]",
      text: "",
    },
    {
      top: "top-[30px]",
      left: "left-1",
      rotate: "rotate-[138.15deg]",
      text: "s",
    },
    {
      top: "top-[123px]",
      left: "left-[102px]",
      rotate: "rotate-[149.66deg]",
      text: "a",
    },
    {
      top: "top-32",
      left: "left-[93px]",
      rotate: "rotate-[160.07deg]",
      text: "l",
    },
    {
      top: "top-[131px]",
      left: "left-20",
      rotate: "rotate-[170.49deg]",
      text: "e",
    },
  ];

  // Data for image rectangles
  const imageRectangles = [
    {
      top: "top-[155px]",
      left: "left-0",
      width: "w-[254px]",
      height: "h-[253px]",
      hasObjectCover: true,
    },
    {
      top: "top-[251px]",
      left: "left-[282px]",
      width: "w-[254px]",
      height: "h-[253px]",
      hasObjectCover: true,
    },
    {
      top: "top-[57px]",
      left: "left-[885px]",
      width: "w-[254px]",
      height: "h-[248px]",
      hasObjectCover: false,
    },
    {
      top: "top-[153px]",
      left: "left-[1168px]",
      width: "w-[254px]",
      height: "h-[253px]",
      hasObjectCover: true,
    },
    {
      top: "top-[331px]",
      left: "left-[886px]",
      width: "w-[254px]",
      height: "h-[163px]",
      hasObjectCover: true,
    },
    {
      top: "top-[59px]",
      left: "left-[283px]",
      width: "w-[254px]",
      height: "h-[163px]",
      hasObjectCover: true,
    },
    {
      top: "top-0",
      left: "left-[566px]",
      width: "w-[291px]",
      height: "h-[561px]",
      hasObjectCover: true,
    },
  ];

  return (
    <section className="relative w-full h-[961px] overflow-hidden">
      <div className="relative h-full">
        {/* Background decorative elements */}
        <div className="absolute w-full h-full top-0 left-0 opacity-40">
          <div className="relative w-full h-full">
            <div className="absolute w-[1360px] right-0 h-full">
              <div className="w-[1204px] h-full">
                {/* Circular text element */}
                <div className="relative w-[145px] h-[145px] top-[247px] left-[818px]">
                  <div className="relative w-[209px] h-[145px]">
                    <div className="absolute w-[209px] h-[145px] top-0 left-0">
                      {circularTextLetters.map((letter, index) => (
                        <div
                          key={`letter-${index}`}
                          className={`absolute ${letter.top} ${letter.left} ${letter.rotate} [-webkit-text-stroke:0.35px_#898f97] [font-family:'Inter',Helvetica] font-semibold text-[#898f97] text-[10.8px] tracking-[0] leading-[normal]`}
                        >
                          {letter.text}
                        </div>
                      ))}
                    </div>

                    <img
                      className="absolute w-[42px] h-[26px] top-[58px] left-[52px]"
                      alt="Arrow"
                      src="/arrow-1.svg"
                    />
                  </div>
                </div>
              </div>
            </div>

            <img
              className="w-[1227px] left-0 absolute h-full"
              alt="Frame"
              src="/frame-2.svg"
            />
          </div>
        </div>

        {/* Image grid section */}
        <Card className="absolute w-[1422px] h-[561px] top-[396px] left-[382px] border-none shadow-none">
          <CardContent className="p-0 relative h-full">
            {imageRectangles.map((rect, index) => (
              <AspectRatio
                key={`rect-${index}`}
                ratio={
                  rect.width.replace("w-", "") / rect.height.replace("h-", "")
                }
                className={`absolute ${rect.top} ${rect.left} ${rect.width} ${rect.height} ${rect.hasObjectCover ? "object-cover" : ""}`}
              >
                <div className="w-full h-full bg-muted" />
              </AspectRatio>
            ))}
          </CardContent>
        </Card>

        {/* Decorative star */}
        <img
          className="absolute w-[49px] h-[49px] top-[850px] left-[1599px]"
          alt="Star"
          src="/star-2.svg"
        />
      </div>
    </section>
  );
};
