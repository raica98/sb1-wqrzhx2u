import React from "react";
import { Satellite, Brain, Target, Zap, CheckCircle, TrendingUp, Clock, BarChart3, Calculator, Users, DollarSign, MapPin, Camera, Utensils, ShoppingBag, TreePine } from "lucide-react";

export const SectionComponentNodeSubsection = (): JSX.Element => {
  return (
    <>
      {/* Main Acreage Sale Section */}
      <section className="w-full py-20 bg-gradient-to-br from-blue-50 via-white to-indigo-50 relative overflow-hidden">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center bg-[#329cf9] text-white px-8 py-4 rounded-full font-bold text-lg shadow-xl mb-8">
              <Zap className="w-6 h-6 mr-3" />
              Acreage Sale — Get Offers in as Soon as 7 Days!
            </div>
            
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-8">
              <span className="text-gray-900">Nothing like it on the market.</span>
            </h2>
            
            <p className="text-xl md:text-2xl text-gray-600 leading-relaxed max-w-5xl mx-auto mb-12">
              Whether you're a realtor looking to boost your listings or a landowner selling by yourself, 
              Acreage Sale gets you offers fast — no matter where your property is or how old the listing.
            </p>
            
            <div className="rounded-3xl p-8 border border-blue-100 max-w-4xl mx-auto mb-16">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">All it takes is your Parcel Number. Everything else is automated.</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <div className="text-center p-6 bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl border border-green-200">
                  <div className="w-16 h-16 bg-[#329cf9] rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                    <DollarSign className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="text-2xl font-bold text-gray-900 mb-2">💰 Save Money</h4>
                  <p className="text-lg font-semibold text-green-600 mb-3">Just $200/month</p>
                  <div className="space-y-2 text-gray-700">
                    <p className="text-sm">• No big commissions unless you choose to work with a buyer's realtor</p>
                    <p className="text-sm">• No need to sell at a deep discount to investors</p>
                    <p className="text-sm">• Keep control of your sale process</p>
                  </div>
                </div>
                
                <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl border border-blue-200">
                  <div className="w-16 h-16 bg-[#329cf9] rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                    <Clock className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="text-2xl font-bold text-gray-900 mb-2">⚡ Get Offers Fast</h4>
                  <p className="text-lg font-semibold text-blue-600 mb-3">As soon as 7 days</p>
                  <div className="space-y-2 text-gray-700">
                    <p className="text-sm">• Works anywhere in the country</p>
                    <p className="text-sm">• No matter how old your listing is</p>
                    <p className="text-sm">• Automated buyer matching system</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Fast AI Listing Generator Feature */}
          <div className="bg-white rounded-3xl p-4 sm:p-8 lg:p-12 shadow-2xl border border-gray-200 mb-20">
            <div className="text-center mb-6 sm:mb-8 lg:mb-12">
              <div className="inline-flex items-center bg-gradient-to-r from-purple-100 to-indigo-100 text-purple-700 px-6 py-3 rounded-full font-semibold text-lg mb-6">
                <Brain className="w-5 h-5 mr-2" />
                1. Fast AI Listing Generator
              </div>
              <h3 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 sm:mb-6">
                Turn your parcel number into a complete, market-ready listing in minutes.
              </h3>
              <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
                Your property comes to life in a way buyers can see, imagine, and want.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
              {/* Automatic Listing Creation */}
              <div className="text-center p-4 sm:p-6 lg:p-8 bg-gradient-to-br from-purple-50 to-violet-50 rounded-2xl border border-purple-200 hover:shadow-lg transition-all duration-300">
                <div className="w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 bg-[#329cf9] rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-lg">
                  <Zap className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-white" />
                </div>
                <h4 className="text-lg sm:text-xl font-bold text-gray-900 mb-2 sm:mb-4">Automatic Listing Creation</h4>
                <p className="text-sm sm:text-base text-gray-600">AI generates professional property descriptions, titles, and market analysis automatically</p>
              </div>

              {/* Satellite Imagery */}
              <div className="text-center p-4 sm:p-6 lg:p-8 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl border border-blue-200 hover:shadow-lg transition-all duration-300">
                <div className="w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 bg-[#329cf9] rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-lg">
                  <Camera className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-white" />
                </div>
                <h4 className="text-lg sm:text-xl font-bold text-gray-900 mb-2 sm:mb-4">Satellite Imagery</h4>
                <p className="text-sm sm:text-base text-gray-600">Multiple angles captured — close-up and wide views that showcase your property perfectly</p>
              </div>

              {/* Nearby Cities Maps */}
              <div className="text-center p-4 sm:p-6 lg:p-8 bg-gradient-to-br from-emerald-50 to-green-50 rounded-2xl border border-emerald-200 hover:shadow-lg transition-all duration-300">
                <div className="w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 bg-[#329cf9] rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-lg">
                  <MapPin className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-white" />
                </div>
                <h4 className="text-lg sm:text-xl font-bold text-gray-900 mb-2 sm:mb-4">Nearby Cities Maps</h4>
                <p className="text-sm sm:text-base text-gray-600">Show buyers what's around — cities, towns, and communities within driving distance</p>
              </div>

              {/* Local Attractions */}
              <div className="text-center p-4 sm:p-6 lg:p-8 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl border border-orange-200 hover:shadow-lg transition-all duration-300">
                <div className="w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 bg-[#329cf9] rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-lg">
                  <TreePine className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-white" />
                </div>
                <h4 className="text-lg sm:text-xl font-bold text-gray-900 mb-2 sm:mb-4">Fun Local Attractions</h4>
                <p className="text-sm sm:text-base text-gray-600">Restaurants, shops, outdoor activities — everything buyers want to know about the area</p>
              </div>
            </div>

            {/* Feature Details */}
            <div className="mt-8 sm:mt-12 lg:mt-16 grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8 lg:gap-12 items-center">
              <div className="space-y-4 sm:space-y-6 lg:space-y-8">
                <div className="space-y-4 sm:space-y-6">
                  {[
                    {
                      icon: Brain,
                      title: "AI-Powered Content Generation",
                      description: "Professional descriptions and titles created instantly using advanced AI technology"
                    },
                    {
                      icon: Satellite,
                      title: "Multi-Angle Satellite Capture",
                      description: "Close-up, wide, and aerial views that show your property from every important perspective"
                    },
                    {
                      icon: MapPin,
                      title: "Location Context Mapping",
                      description: "Nearby cities, amenities, and attractions automatically mapped and highlighted"
                    },
                    {
                      icon: Target,
                      title: "Buyer-Focused Presentation",
                      description: "Everything presented in a way that helps buyers visualize and connect with your property"
                    }
                  ].map((feature, index) => (
                    <div key={index} className="flex items-start gap-3 sm:gap-4">
                      <div className="w-10 h-10 sm:w-12 sm:h-12 bg-[#329cf9] rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                        <feature.icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                      </div>
                      <div>
                        <h5 className="text-lg sm:text-xl font-bold text-gray-900 mb-1 sm:mb-2">{feature.title}</h5>
                        <p className="text-sm sm:text-base text-gray-600">{feature.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="relative">
                <div className="bg-gradient-to-r from-[#329cf9] to-[#2b354c] rounded-3xl p-4 sm:p-6 lg:p-8 shadow-2xl">
                  <div className="bg-white rounded-2xl p-4 sm:p-6 space-y-4 sm:space-y-6">
                    <div className="flex items-center gap-3 mb-4 sm:mb-6">
                      <Brain className="w-6 h-6 sm:w-8 sm:h-8 text-[#329cf9]" />
                      <span className="text-lg sm:text-xl font-bold text-gray-900">AI Listing Generator</span>
                    </div>
                    
                    <div className="space-y-3 sm:space-y-4">
                      <div className="bg-gray-50 rounded-lg p-3 sm:p-4">
                        <div className="text-xs sm:text-sm text-gray-600 mb-2">Input: Parcel Number</div>
                        <div className="font-mono text-[#329cf9] font-bold text-sm sm:text-base">APN: 123-456-789</div>
                      </div>
                      
                      <div className="text-center py-3 sm:py-4">
                        <div className="w-6 h-6 sm:w-8 sm:h-8 border-4 border-[#329cf9] border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                        <div className="text-xs sm:text-sm text-gray-600">AI Processing...</div>
                      </div>
                      
                      <div className="bg-green-50 rounded-lg p-3 sm:p-4 border border-green-200">
                        <div className="text-xs sm:text-sm text-gray-600 mb-2">Output: Complete Listing</div>
                        <div className="space-y-1 sm:space-y-2">
                          <div className="flex items-center gap-2">
                            <CheckCircle className="w-3 h-3 sm:w-4 sm:h-4 text-green-600" />
                            <span className="text-xs sm:text-sm font-medium">Professional description</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <CheckCircle className="w-3 h-3 sm:w-4 sm:h-4 text-green-600" />
                            <span className="text-xs sm:text-sm font-medium">Satellite imagery captured</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <CheckCircle className="w-3 h-3 sm:w-4 sm:h-4 text-green-600" />
                            <span className="text-xs sm:text-sm font-medium">Nearby attractions mapped</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <CheckCircle className="w-3 h-3 sm:w-4 sm:h-4 text-green-600" />
                            <span className="text-xs sm:text-sm font-medium">Ready for buyer offers</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Market Analyzer Section */}
      <section className="w-full py-20 bg-gradient-to-br from-purple-50 via-white to-violet-50 relative overflow-hidden">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center bg-gradient-to-r from-[#329cf9] to-[#2b354c] text-white px-8 py-4 rounded-full font-bold text-lg shadow-xl mb-8">
              <BarChart3 className="w-6 h-6 mr-3" />
              2. Land Comping
            </div>
            
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-8">
              <span className="text-gray-900">Our AI pulls recent land sales in your area and instantly shows you:</span>
            </h2>
            
            <p className="text-xl md:text-2xl text-gray-600 leading-relaxed max-w-4xl mx-auto mb-12">
              You get the data to price your property with confidence.
            </p>
          </div>

          {/* Three Market Value Options */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {/* High Market Value */}
            <div className="bg-white rounded-3xl p-8 shadow-2xl border border-green-200 hover:shadow-3xl transition-all duration-300 group">
              <div className="text-center">
                <div className="w-20 h-20 bg-[#329cf9] rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:scale-110 transition-transform">
                  <TrendingUp className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">High Market Value</h3>
                <p className="text-lg text-gray-600 mb-6">for the best possible price</p>
                
                <div className="bg-green-50 rounded-2xl p-6 border border-green-200">
                  <div className="text-3xl font-bold text-green-600 mb-2">$125,000</div>
                  <div className="text-sm text-green-700 font-medium">Premium Market Price</div>
                  <div className="text-xs text-green-600 mt-2">Based on recent comparable sales</div>
                </div>
                
                <div className="mt-6 space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span className="text-gray-700 text-sm">Maximum profit potential</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span className="text-gray-700 text-sm">Premium buyer targeting</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span className="text-gray-700 text-sm">Extended marketing timeline</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Medium Market Value */}
            <div className="bg-white rounded-3xl p-8 shadow-2xl border border-blue-200 hover:shadow-3xl transition-all duration-300 group relative">
              {/* Recommended Badge */}
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-[#329cf9] to-[#2b354c] text-white px-6 py-2 rounded-full text-sm font-bold shadow-lg">
                RECOMMENDED
              </div>
              
              <div className="text-center">
                <div className="w-20 h-20 bg-[#329cf9] rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:scale-110 transition-transform">
                  <Zap className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Medium Market Value</h3>
                <p className="text-lg text-gray-600 mb-6">for faster sales</p>
                
                <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200">
                  <div className="text-3xl font-bold text-blue-600 mb-2">$95,000</div>
                  <div className="text-sm text-blue-700 font-medium">Balanced Market Price</div>
                  <div className="text-xs text-blue-600 mt-2">Optimal speed vs. profit ratio</div>
                </div>
                
                <div className="mt-6 space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-blue-600" />
                    <span className="text-gray-700 text-sm">Faster sale timeline</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-blue-600" />
                    <span className="text-gray-700 text-sm">Balanced pricing strategy</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-blue-600" />
                    <span className="text-gray-700 text-sm">Broader buyer appeal</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Low Market Value */}
            <div className="bg-white rounded-3xl p-8 shadow-2xl border border-orange-200 hover:shadow-3xl transition-all duration-300 group">
              <div className="text-center">
                <div className="w-20 h-20 bg-[#329cf9] rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:scale-110 transition-transform">
                  <Clock className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Low Market Value</h3>
                <p className="text-lg text-gray-600 mb-6">for investors who want a quick deal</p>
                
                <div className="bg-orange-50 rounded-2xl p-6 border border-orange-200">
                  <div className="text-3xl font-bold text-orange-600 mb-2">$75,000</div>
                  <div className="text-sm text-orange-700 font-medium">Quick Sale Price</div>
                  <div className="text-xs text-orange-600 mt-2">Attracts cash investors</div>
                </div>
                
                <div className="mt-6 space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-orange-600" />
                    <span className="text-gray-700 text-sm">Fastest sale possible</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-orange-600" />
                    <span className="text-gray-700 text-sm">Cash investor appeal</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-orange-600" />
                    <span className="text-gray-700 text-sm">Quick closing guaranteed</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* AI Comping Process Visualization */}
          <div className="rounded-3xl p-12 border border-gray-200">
            <div className="text-center mb-12">
              <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                AI Land Comping in Action
              </h3>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Watch how our AI analyzes recent sales data to give you three strategic pricing options
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              {/* Left side - Process steps */}
              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#329cf9] rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <span className="text-white font-bold text-lg">1</span>
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">AI Scans Recent Sales</h4>
                    <p className="text-gray-600">Our AI analyzes all land sales in your area from the past 12 months, identifying comparable properties by size, location, and features.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#329cf9] rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <span className="text-white font-bold text-lg">2</span>
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">Market Analysis</h4>
                    <p className="text-gray-600">Advanced algorithms calculate market trends, demand patterns, and pricing strategies based on current market conditions.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#329cf9] rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <span className="text-white font-bold text-lg">3</span>
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">Three Strategic Options</h4>
                    <p className="text-gray-600">Get three pricing strategies: premium for maximum profit, balanced for faster sales, or quick-sale for immediate cash offers.</p>
                  </div>
                </div>
              </div>
              
              {/* Right side - Visual demonstration */}
              <div className="relative">
                <div className="bg-gradient-to-r from-[#329cf9] to-[#2b354c] rounded-2xl sm:rounded-3xl p-6 sm:p-6 lg:p-8 shadow-2xl w-full max-w-sm sm:max-w-none mx-auto">
                  <div className="bg-white rounded-xl sm:rounded-2xl p-3 sm:p-4 lg:p-6">
                    <div className="flex items-center gap-3 mb-6">
                      <BarChart3 className="w-6 h-6 sm:w-8 sm:h-8 text-[#329cf9]" />
                      <span className="text-lg sm:text-xl font-bold text-gray-900">AI Land Comping Results</span>
                    </div>
                    
                    <div className="space-y-3 sm:space-y-4">
                      <div className="p-3 sm:p-4 bg-green-50 rounded-lg border-l-4 border-green-500">
                        <div className="flex justify-between items-center">
                          <span className="font-semibold text-gray-900 text-sm sm:text-base">High Market Value</span>
                          <span className="text-green-600 font-bold text-sm sm:text-base">$125,000</span>
                        </div>
                        <div className="text-xs sm:text-sm text-green-600 mt-1">Best possible price • 90-120 days</div>
                      </div>
                      
                      <div className="p-3 sm:p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500 ring-2 ring-blue-200">
                        <div className="flex justify-between items-center">
                          <span className="font-semibold text-gray-900 text-sm sm:text-base">Medium Market Value</span>
                          <span className="text-blue-600 font-bold text-sm sm:text-base">$95,000</span>
                        </div>
                        <div className="text-xs sm:text-sm text-blue-600 mt-1">Faster sales • 30-60 days</div>
                        <div className="text-xs text-blue-500 mt-1 font-medium">⭐ RECOMMENDED</div>
                      </div>
                      
                      <div className="p-3 sm:p-4 bg-orange-50 rounded-lg border-l-4 border-orange-500">
                        <div className="flex justify-between items-center">
                          <span className="font-semibold text-gray-900 text-sm sm:text-base">Low Market Value</span>
                          <span className="text-orange-600 font-bold text-sm sm:text-base">$75,000</span>
                        </div>
                        <div className="text-xs sm:text-sm text-orange-600 mt-1">Quick deal • 7-14 days</div>
                      </div>
                    </div>
                    
                    <div className="mt-4 sm:mt-6 p-3 sm:p-4 bg-gray-50 rounded-lg">
                      <div className="text-xs sm:text-sm text-gray-600 mb-2">Based on 47 comparable sales in your area</div>
                      <div className="flex justify-between text-xs text-gray-500">
                        <span>Confidence Score: 94%</span>
                        <span>Last Updated: 2 hours ago</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Augmented Reality Property Viewing Section */}
      <section className="w-full py-20 bg-gradient-to-br from-indigo-50 via-white to-purple-50 relative overflow-hidden">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center bg-[#329cf9] text-white px-8 py-4 rounded-full font-bold text-lg shadow-xl mb-8">
              <Camera className="w-6 h-6 mr-3" />
              3. Augmented Reality Property Viewing
            </div>
            
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-8">
              <span className="text-gray-900">Let buyers walk the land without you being there.</span>
            </h2>
            
            <div className="text-xl md:text-2xl text-gray-600 leading-relaxed max-w-4xl mx-auto mb-12 space-y-6">
              <div className="space-y-4">
                <p>Click "View in AR" and see red-dot corner markers in real time</p>
                <p>Buyers can follow property boundaries from their phone's camera</p>
                <p>You save time while giving them a true on-site experience</p>
              </div>
            </div>
            
            {/* AR Examples with Visuals */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              {/* Left side - Phone AR Example */}
              <div className="text-center">
                <div className="relative inline-block">
                  {/* Phone mockup */}
                  <div className="w-80 h-[600px] bg-black rounded-[3rem] p-4 shadow-2xl">
                    <div className="w-full h-full bg-gray-900 rounded-[2rem] overflow-hidden relative">
                      {/* Land background image */}
                      <img
                        src="https://assets.land.com/resizedimages/304/430/l/80/w/1-5329582059"
                        alt="Land property view"
                        className="w-full h-full object-cover"
                      />
                      
                      {/* AR Corner Markers */}
                      <div className="absolute top-16 left-12">
                        <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse shadow-lg border-2 border-white"></div>
                        <div className="text-white text-xs font-bold mt-1 bg-black/50 px-2 py-1 rounded">Corner 1</div>
                      </div>
                      <div className="absolute top-20 right-16">
                        <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse shadow-lg border-2 border-white"></div>
                        <div className="text-white text-xs font-bold mt-1 bg-black/50 px-2 py-1 rounded">Corner 2</div>
                      </div>
                      <div className="absolute bottom-32 left-20">
                        <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse shadow-lg border-2 border-white"></div>
                        <div className="text-white text-xs font-bold mt-1 bg-black/50 px-2 py-1 rounded">Corner 3</div>
                      </div>
                      <div className="absolute bottom-28 right-12">
                        <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse shadow-lg border-2 border-white"></div>
                        <div className="text-white text-xs font-bold mt-1 bg-black/50 px-2 py-1 rounded">Corner 4</div>
                      </div>
                      
                      {/* AR UI Elements */}
                      <div className="absolute top-4 left-4 right-4 flex justify-between items-center">
                        <div className="bg-black/50 text-white px-3 py-1 rounded-full text-xs font-medium">
                          🔴 LIVE AR VIEW
                        </div>
                        <div className="bg-black/50 text-white px-3 py-1 rounded-full text-xs font-medium">
                          GPS: ±3m
                        </div>
                      </div>
                      
                      <div className="absolute bottom-4 left-4 right-4">
                        <div className="bg-black/70 text-white p-3 rounded-lg text-center">
                          <div className="text-sm font-bold">2.5-Acre Property</div>
                          <div className="text-xs opacity-90">Walk to each corner to explore boundaries</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <h4 className="text-xl font-bold text-gray-900 mb-2">Live AR Boundary Markers</h4>
                    <p className="text-gray-600">Red dots show property corners in real-time through phone camera</p>
                  </div>
                </div>
              </div>
              
              {/* Right side - Land Property Example */}
              <div className="text-center">
                <div className="relative">
                  {/* Land image with boundary overlay */}
                  <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                    <img
                      src="https://isu-armac.com/wp-content/uploads/2021/09/vacant-land-insurance-scaled-1.jpg"
                      alt="Aerial view of land property"
                      className="w-full h-80 object-cover"
                    />
                    
                    {/* Property boundary overlay */}
                    <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 320">
                      <polygon
                        points="80,60 320,80 300,240 60,220"
                        fill="rgba(239, 68, 68, 0.2)"
                        stroke="#ef4444"
                        strokeWidth="3"
                        strokeDasharray="10,5"
                        className="animate-pulse"
                      />
                      
                      {/* Corner markers */}
                      <circle cx="80" cy="60" r="6" fill="#ef4444" className="animate-pulse" />
                      <circle cx="320" cy="80" r="6" fill="#ef4444" className="animate-pulse" />
                      <circle cx="300" cy="240" r="6" fill="#ef4444" className="animate-pulse" />
                      <circle cx="60" cy="220" r="6" fill="#ef4444" className="animate-pulse" />
                      
                      {/* Labels */}
                      <text x="80" y="50" fill="white" fontSize="12" fontWeight="bold" textAnchor="middle">1</text>
                      <text x="320" y="70" fill="white" fontSize="12" fontWeight="bold" textAnchor="middle">2</text>
                      <text x="300" y="255" fill="white" fontSize="12" fontWeight="bold" textAnchor="middle">3</text>
                      <text x="60" y="235" fill="white" fontSize="12" fontWeight="bold" textAnchor="middle">4</text>
                    </svg>
                    
                    {/* Property info overlay */}
                    <div className="absolute top-4 left-4 bg-black/70 text-white px-4 py-2 rounded-lg">
                      <div className="text-sm font-bold">2.5 Acres</div>
                      <div className="text-xs opacity-90">Austin, Texas</div>
                    </div>
                    
                    <div className="absolute top-4 right-4 bg-[#329cf9] text-white px-4 py-2 rounded-lg">
                      <div className="text-sm font-bold">$125,000</div>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <h4 className="text-xl font-bold text-gray-900 mb-2">Property Boundary Visualization</h4>
                    <p className="text-gray-600">Buyers see exact property lines and corners through AR technology</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* AR Features Grid */}
            <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center p-8 bg-white rounded-2xl shadow-lg border border-gray-200">
                <div className="w-16 h-16 bg-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <span className="text-white text-2xl">📱</span>
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-4">Real-Time Markers</h4>
                <p className="text-gray-600">Red dots appear exactly where property corners are located using GPS precision</p>
              </div>
              
              <div className="text-center p-8 bg-white rounded-2xl shadow-lg border border-gray-200">
                <div className="w-16 h-16 bg-green-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <span className="text-white text-2xl">🚶</span>
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-4">Walk the Boundaries</h4>
                <p className="text-gray-600">Buyers can physically walk to each corner and see the property lines in their camera view</p>
              </div>
              
              <div className="text-center p-8 bg-white rounded-2xl shadow-lg border border-gray-200">
                <div className="w-16 h-16 bg-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <span className="text-white text-2xl">⏰</span>
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-4">Save Time</h4>
                <p className="text-gray-600">No need for in-person property tours - buyers get the full experience remotely</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Buyer Matching Section */}
      <section className="w-full py-20 bg-gradient-to-br from-emerald-50 via-white to-green-50 relative overflow-hidden">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center bg-[#329cf9] text-white px-8 py-4 rounded-full font-bold text-lg shadow-xl mb-8">
              <Users className="w-6 h-6 mr-3" />
              4. Buyer Matching
            </div>
            
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-8">
              <span className="text-gray-900">We connect your land with three powerful buyer groups:</span>
            </h2>
            
            <div className="text-xl md:text-2xl text-gray-600 leading-relaxed max-w-4xl mx-auto mb-12 space-y-6">
              <div className="space-y-4">
                <p><strong>Local Buyers</strong> — people nearby who want more land for themselves, family, or friends</p>
                <p><strong>Realtors with Active Buyers</strong> — no long contracts; negotiate commissions directly or have the buyer pay</p>
                <p><strong>Investors & Developers</strong> — active in your area and ready to make offers</p>
              </div>
              <p className="pt-4">
                We start with letters, emails, and ads — and if you're still looking after 30 days, we launch Facebook and Google Ads targeting people already interested in your area.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};