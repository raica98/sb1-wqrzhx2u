import React from "react";

/** Recreated WP page with sane layout & typography */
export default function PhelanPage() {
  return (
    <main className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-10">
      {/* Title */}
      <h1 className="text-3xl md:text-4xl font-semibold tracking-tight text-gray-900">
        Exploring Vacant Land Opportunities in Phelan: A 5-Acre Lot with Utility Access
      </h1>

      {/* Hero image with proper aspect + cover (won't stretch) */}
      <figure className="mt-6 overflow-hidden rounded-2xl">
        <div className="relative w-full" style={{ aspectRatio: "16 / 9" }}>
          <img
            src="https://acreagesale.com/wp-content/uploads/2024/08/gray-wooden-house-surrounded-with-green-trees-under-blue-and-white-sky-scaled.jpg"
            alt="gray wooden house surrounded with green trees under blue and white sky"
            className="absolute inset-0 h-full w-full object-cover"
            loading="eager"
          />
        </div>
      </figure>

      {/* WP content */}
      <article
        className="prose prose-slate lg:prose-lg mt-8 max-w-none"
        // the prose classes handle headings, lists, spacing, link styles
        dangerouslySetInnerHTML={{
          __html: `
<h2 class="wp-block-heading">Discovering Phelan</h2>
<p>If you are looking for an ideal plot for development or investment, the vacant land in Phelan offers an excellent opportunity. This 5-acre parcel is perfectly situated in a region known for its expansive views and serene environment. With easy access to basic utilities, this land could be your canvas for future projects.</p>
<h2 class="wp-block-heading">Utility Access</h2>
<p>One of the most appealing aspects of this vacant land is its utility access. The lot comes with both water and power available right up to the street, simplifying the logistics of any future construction. You won't have to worry about the complexity and costs involved in bringing these essential services to your development.</p>
<h2 class="wp-block-heading">Potential Uses</h2>
<p>Whether you're planning to build your dream home, set up an agricultural endeavor, or consider a mixed use, this 5-acre plot provides the flexibility you need. The availability of utilities to the street gives you a head start, making this land not only a beautiful but also a practical choice for various types of projects.</p>
<h2 class="wp-block-heading">Why Choose Phelan?</h2>
<p>Phelan is a community that balances rural charm with accessibility. It offers peace and tranquility while being not too far from urban amenities. Investing in a 5-acre lot here means embracing both nature and convenience. This land is an excellent starting point whether you aim for a private haven or a profitable investment.</p>
          `.trim(),
        }}
      />
    </main>
  );
}